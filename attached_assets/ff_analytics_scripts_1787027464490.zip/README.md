# Top-250 NFL Fantasy Analytics

Builds a formatted Excel workbook covering the top 250 fantasy-relevant
QB/RB/WR/TE for the 2026 season, blending 2025 NFL production, 2026 draft-market
data, and computed team/offensive-line context.

Every data source is free and unauthenticated. No API keys, no PFF subscription.

## Install

```bash
pip install pandas numpy pyarrow openpyxl rapidfuzz
```

## Run

```bash
python -m ff_analytics.build --out top250_2026_fantasy_analytics.xlsx --csv
```

| Flag | Effect |
|---|---|
| `--out PATH` | output workbook path |
| `--n 250` | how many players |
| `--csv` | also write the master table as CSV |
| `--refresh` | ignore the local cache and re-download every source |

First run downloads ~120MB (play-by-play is the bulk of it) into `~/.ff_cache`
and takes a couple of minutes. Later runs read the cache and take seconds.
The cache expires after 24 hours.

## Live ADP

On an open network the script pulls real ADP from Fantasy Football Calculator,
falling back to Sleeper. If neither is reachable it falls back to FantasyPros
expert consensus rankings and labels every row in the `adp_source` column, so
you always know which one you are looking at. Nothing silently substitutes.

## Output tabs

| Tab | What it is |
|---|---|
| Master | all 250, ~95 columns, colour-scaled |
| QB / RB / WR / TE | position views, re-scaled *within* position |
| Value Board | sorted by production-vs-price gap |
| Team Context | all 32 offences: O-line grades, pace, PROE, vacated volume |
| Methodology | every formula, source URL, and known limitation |
| Raw | unformatted full merge, for pivoting |

## Reading the columns

- `'25 ...` — actual 2025 regular-season production
- `tm_ ...` / Team Context tab — the **2026** team's situation
- starred shares (`Tgt Share*`) — computed over weeks the player took a snap
- **blank ≠ zero** — blank means no 2025 snaps (rookie or missed season, see
  Notes) or a sample too small to report; zero means he played and produced
  nothing

## Sources

nflverse (play-by-play, weekly stats, Next Gen Stats, snap counts, rosters,
depth charts, PFR advanced stats), DynastyProcess (FantasyPros ECR mirror and
the ID crosswalk), Fantasy Football Calculator / Sleeper (live ADP).

## Verification

`python verify.py` runs 35 integrity checks: share sums, an independent
recomputation of PPR totals from raw box-score components, O-line grade bounds,
blank-vs-zero discipline, and 2026-team join correctness.
