"""Render the analytics tables into a formatted Excel workbook."""
from __future__ import annotations

import time

import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from . import columns as C
from .config import MARKET_SEASON, STAT_SEASON

FONT = "Arial"
HEADER_FILL = PatternFill("solid", fgColor="1F3B57")
HEADER_FONT = Font(name=FONT, bold=True, color="FFFFFF", size=9)
BODY_FONT = Font(name=FONT, size=10)
TITLE_FONT = Font(name=FONT, bold=True, size=13, color="1F3B57")
NOTE_FONT = Font(name=FONT, size=9, italic=True, color="595959")

POS_FILL = {
    "QB": PatternFill("solid", fgColor="E8EEF7"),
    "RB": PatternFill("solid", fgColor="E9F3EA"),
    "WR": PatternFill("solid", fgColor="FDF0E6"),
    "TE": PatternFill("solid", fgColor="F3EAF5"),
}
THIN = Side(style="thin", color="D9D9D9")
BORDER = Border(bottom=THIN)

# Colour scales. 'up' = high is good (green at the top).
SCALE_UP = ColorScaleRule(start_type="percentile", start_value=5, start_color="F8696B",
                          mid_type="percentile", mid_value=50, mid_color="FFEB84",
                          end_type="percentile", end_value=95, end_color="63BE7B")
SCALE_DOWN = ColorScaleRule(start_type="percentile", start_value=5, start_color="63BE7B",
                            mid_type="percentile", mid_value=50, mid_color="FFEB84",
                            end_type="percentile", end_value=95, end_color="F8696B")


def _clean(v):
    """openpyxl cannot write NaN/NaT/numpy scalars; normalise them here."""
    if v is None:
        return None
    if isinstance(v, float) and (np.isnan(v) or np.isinf(v)):
        return None
    if v is pd.NA or (not isinstance(v, (list, tuple, np.ndarray)) and pd.isna(v)):
        return None
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return float(v)
    if isinstance(v, (np.bool_,)):
        return bool(v)
    return v


def _write_sheet(wb: Workbook, title: str, df: pd.DataFrame,
                 layout: list, freeze: str = "E2",
                 subtitle: str | None = None, use_formulas: bool = True):
    ws = wb.create_sheet(title)
    layout = [c for c in layout if c[0] in df.columns]
    col_of = {spec[0]: i + 1 for i, spec in enumerate(layout)}

    header_row = 1
    if subtitle:
        ws.cell(1, 1, subtitle).font = NOTE_FONT
        header_row = 2
        freeze = freeze[0] + str(int(freeze[1:]) + 1)

    for i, (key, head, fmt, direction) in enumerate(layout, start=1):
        c = ws.cell(header_row, i, head)
        c.font = HEADER_FONT
        c.fill = HEADER_FILL
        c.alignment = Alignment(horizontal="center", vertical="center",
                                wrap_text=True)

    first = header_row + 1
    for r, (_, row) in enumerate(df.iterrows(), start=first):
        for i, (key, head, fmt, direction) in enumerate(layout, start=1):
            cell = ws.cell(r, i)
            wrote_formula = False
            value = _clean(row.get(key))

            # Only emit a live formula where the computed value exists. A blank
            # here is deliberate -- a rookie with no 2025 snaps, or a rate
            # suppressed for a tiny sample -- and `=IFERROR(A-B,"")` on two
            # empty cells evaluates to 0, not to blank, which would print a
            # confident 0.00 where the honest answer is "no data".
            if value is None:
                use_f = False
            else:
                use_f = use_formulas

            if use_f and key in C.FORMULA_RATIOS:
                num, den = C.FORMULA_RATIOS[key]
                if num in col_of and den in col_of:
                    n, d = get_column_letter(col_of[num]), get_column_letter(col_of[den])
                    cell.value = f'=IFERROR({n}{r}/{d}{r},"")'
                    wrote_formula = True
            elif use_f and key in C.FORMULA_DIFFS:
                a, b = C.FORMULA_DIFFS[key]
                if a in col_of and b in col_of:
                    x, y = get_column_letter(col_of[a]), get_column_letter(col_of[b])
                    cell.value = f'=IFERROR({x}{r}-{y}{r},"")'
                    wrote_formula = True

            if not wrote_formula:
                cell.value = value

            cell.font = BODY_FONT
            if fmt:
                cell.number_format = fmt
            cell.border = BORDER
            if key == "position":
                cell.fill = POS_FILL.get(row.get("position"), PatternFill())
                cell.alignment = Alignment(horizontal="center")
            elif key in ("rank", "depth_rank_2026", "bye", "years_of_experience"):
                cell.alignment = Alignment(horizontal="center")

    last = first + len(df) - 1
    if last >= first:
        for i, (key, head, fmt, direction) in enumerate(layout, start=1):
            if not direction:
                continue
            L = get_column_letter(i)
            ws.conditional_formatting.add(
                f"{L}{first}:{L}{last}",
                SCALE_UP if direction == "up" else SCALE_DOWN)

        ws.auto_filter.ref = (f"A{header_row}:"
                              f"{get_column_letter(len(layout))}{last}")

    ws.freeze_panes = freeze
    ws.row_dimensions[header_row].height = 34
    for i, (key, head, fmt, direction) in enumerate(layout, start=1):
        width = 22 if key in ("player", "notes", "market_verdict") else \
                12 if len(head) > 9 else 9
        if key == "notes":
            width = 44
        ws.column_dimensions[get_column_letter(i)].width = width
    return ws


def _methodology(wb: Workbook, fetch_log, adp_source, match_summary,
                 team_count: int, player_count: int):
    ws = wb.create_sheet("Methodology")
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 96
    r = 1

    def head(text):
        nonlocal r
        ws.cell(r, 1, text).font = TITLE_FONT
        r += 1

    def line(k, v):
        nonlocal r
        a = ws.cell(r, 1, k); a.font = Font(name=FONT, bold=True, size=9)
        b = ws.cell(r, 2, v); b.font = Font(name=FONT, size=9)
        b.alignment = Alignment(wrap_text=True, vertical="top")
        r += 1

    head(f"Top {player_count} Fantasy Analytics — {MARKET_SEASON} season")
    line("Built", time.strftime("%Y-%m-%d %H:%M"))
    line("Production season", f"{STAT_SEASON} regular season only (weeks 1-18). "
         "Playoffs are excluded: only 14 teams play them, so including them "
         "would quietly reward players on good teams in every per-game column.")
    line("Market season", f"{MARKET_SEASON} draft data")
    line("Column prefixes", "'25 = actual 2025 production · tm_ = 2026 team "
         "context · everything else is 2026 market or biographical data. A "
         "column is never a blend of the two seasons.")
    line("ADP source", adp_source)
    line("Identity match", match_summary)
    line("Teams graded", str(team_count))
    r += 1

    head("Offensive line: how the grades are computed")
    line("Why computed, not sourced", "There is no free public O-line grade. "
         "ESPN's Run/Pass Block Win Rate and PFF's grades are both paywalled. "
         "These grades are therefore computed from play-by-play using the "
         "public Football Outsiders methodology.")
    line("Adjusted Line Yards", "Each running-back carry is credited to the "
         "line on a sliding scale, because a 3-yard gain is the blocking and a "
         "40-yard gain is the runner: losses at 120%, 0-4 yards at 100%, 5-10 "
         "yards at 50%, 11+ yards at 0% (capped at 7.0). Then adjusted for the "
         "run defences actually faced. QB scrambles and kneels are excluded.")
    line("Stuff Rate", "Share of carries gaining 0 or fewer yards. "
         "Opponent-adjusted. Lower is better.")
    line("Power Success", "Conversion rate on 3rd/4th down with 2 or fewer to "
         "go, plus goal-to-go carries from inside the 2.")
    line("Second Level / Open Field", "Yards earned 5-10 and 11+ yards past "
         "the line, per carry. Mostly the runner; shown as a control.")
    line("Run Block Grade", "Weighted z-score blend rescaled 0-100 where 50 is "
         "league average: Adjusted Line Yards 40%, Stuff Rate 20%, Power "
         "Success 15%, Yards Before Contact 25%.")
    line("Pass Block Grade", "Pressure rate allowed 45%, opponent-adjusted "
         "sack rate allowed 35%, average pocket time 20%. Same 0-100 scale.")
    line("OL Continuity", "Share of 2025 offensive-line snaps played by men "
         "who are on that team's 2026 roster, plus how many of the five "
         "projected 2026 starters logged 200+ snaps there in 2025. A 90-grade "
         "line at 40% continuity is a very different bet from 90 at 95%.")
    r += 1

    head("Player metrics")
    line("Target / Carry Share*", "Starred share columns are computed over "
         "only the weeks the player actually appeared, which is what carries "
         "forward. The unstarred versions use the team's full season and are "
         "dragged down by missed time. Both are in the Raw tab.")
    line("WOPR", "1.5 x target share + 0.7 x air-yards share.")
    line("Boom / Bust", "Boom = a week finishing top-12 at the position "
         "(top-6 for TE). Bust = a week under half the positional median. "
         "Both computed over weeks played, not weeks on the roster.")
    line("Floor / Ceiling", "25th and 85th percentile of weekly PPR scores in "
         "games played.")
    line("Expected TDs", "Every carry and target is assigned the league's "
         "empirical touchdown probability for that yard line and play type, "
         "then summed. TD Over Expected separates a back who scored twelve "
         "times from inside the 5 (repeatable) from one who scored twelve "
         "times on breakaways (not).")
    line("Vacated opportunity", "2025 targets, carries and red-zone touches "
         "produced by players who are no longer on that team's 2026 roster. "
         "Somebody has to absorb them.")
    line("Value Score", "Position-relative z-score of 2025 PPR finish minus "
         "the z-score of 2026 ADP. Positive means the market is discounting "
         "last year's production. Read it beside Vacated Opportunity and OL "
         "Continuity to tell 'cheap because the market is wrong' from 'cheap "
         "because the situation collapsed'.")
    line("Blank vs zero", "A blank production cell means no 2025 NFL snaps "
         "(rookie, or missed the season) — see the Notes column. Zero means "
         "he played and produced nothing. Rate stats are suppressed below 4 "
         "games because they are noise at that sample size.")
    r += 1

    head("Known limitations")
    line("No route data", "Yards per route run is the best receiver "
         "efficiency metric available and it is paywalled (PFF / TruMedia). "
         "Yards per target and snap share stand in. They correlate; they are "
         "not the same thing.")
    line("Unit-level O-line", "Grades describe the unit, not individual "
         "linemen. No free per-lineman grade exists.")
    line("Not a projection", "This describes what happened in 2025 and what "
         "the market believes in 2026. Coordinator changes, scheme changes "
         "and free agency are not modelled.")
    line("Preseason timing", "2026 depth charts shift through final cuts. "
         "Re-run the script to refresh.")
    r += 1

    head("Sources")
    for entry in fetch_log:
        line(f"{entry['source']} ({entry['status']}, {entry['rows']:,} rows)",
             entry["url"])
    return ws


def write(result: dict, path: str, fetch_log: list, adp_source: str):
    m = result["master"]
    wb = Workbook()
    wb.remove(wb.active)

    _write_sheet(wb, "Master", m, C.MASTER, freeze="E2",
                 subtitle=(f"Top {len(m)} for {MARKET_SEASON}, full PPR. "
                           f"Columns marked '25 are actual {STAT_SEASON} "
                           f"production; tm_ columns describe the {MARKET_SEASON} "
                           f"team. Starred shares (*) count only weeks played. "
                           f"See Methodology."))

    for pos in ("QB", "RB", "WR", "TE"):
        sub = m[m["position"] == pos].copy()
        if sub.empty:
            continue
        sub = sub.sort_values("ecr")
        sub["rank"] = np.arange(1, len(sub) + 1)
        _write_sheet(wb, pos, sub, C.POSITION_LAYOUTS[pos], freeze="E2",
                     subtitle=(f"{len(sub)} {pos}s. Colour scales are computed "
                               f"within this tab, so a shade here means "
                               f"'good for a {pos}', not 'good overall'."))

    val = m.sort_values("value_score", ascending=False).copy()
    val["rank"] = np.arange(1, len(val) + 1)
    _write_sheet(wb, "Value Board", val,
                 C.IDENTITY + C.MARKET + C.VALUE
                 + [c for c in C.FANTASY if c[0] in
                    ("y25_ppr_total", "y25_ppr_ppg", "y25_games", "y25_pos_finish")]
                 + C.VACATED
                 + [c for c in C.TEAM if c[0] in
                    ("tm_ol_overall_grade", "tm_ol_continuity_pct",
                     "tm_returning_starters", "tm_proe", "tm_points_per_game")],
                 freeze="E2", use_formulas=False,
                 subtitle=("Sorted by Value Score: 2025 positional production "
                           "against 2026 draft price. Check Vacated Opportunity "
                           "and OL Continuity before trusting a bargain."))

    team = result["team"].merge(result["vacated"], on="team", how="left") \
                         .sort_values("ol_overall_grade", ascending=False)
    _write_sheet(wb, "Team Context", team, C.TEAM_TAB, freeze="B2",
                 use_formulas=False,
                 subtitle=(f"All 32 offences, {STAT_SEASON} regular season. "
                           "O-line grades are 0-100 with 50 as league average. "
                           "Vacated columns are 2026-roster-aware."))

    raw = m.copy()
    ws = wb.create_sheet("Raw")
    ws.append([str(c) for c in raw.columns])
    for c in ws[1]:
        c.font = HEADER_FONT
        c.fill = HEADER_FILL
    for _, row in raw.iterrows():
        ws.append([_clean(v) for v in row.tolist()])
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = (f"A1:{get_column_letter(len(raw.columns))}"
                          f"{len(raw) + 1}")

    match_summary = ", ".join(f"{k}={v}" for k, v in
                              m["id_match"].value_counts().items())
    _methodology(wb, fetch_log, adp_source, match_summary,
                 len(result["team"]), len(m))

    wb.save(path)
    return path
