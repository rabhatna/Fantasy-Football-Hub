"""Column layout and display metadata for the workbook.

Each entry is (dataframe column, header shown in the sheet, number format,
colour-scale direction). Direction 'up' means a higher number is better and
should shade green; 'down' means lower is better; None means no scale.
"""

PCT = "0.0%"
PCT2 = "0.00%"
NUM1 = "0.0"
NUM2 = "0.00"
NUM3 = "0.000"
INT = "#,##0"

IDENTITY = [
    ("rank", "Rank", INT, None),
    ("player", "Player", None, None),
    ("position", "Pos", None, None),
    ("pos_rank_label", "Pos Rank", None, None),
    ("team_2026", "2026 Team", None, None),
    ("depth_slot_2026", "Depth Slot", None, None),
    ("depth_rank_2026", "Depth #", INT, "down"),
    ("age", "Age", NUM1, None),
    ("years_of_experience", "Exp", INT, None),
    ("bye", "Bye", INT, None),
]

MARKET = [
    ("adp", "ADP", NUM2, "down"),
    ("adp_stdev", "ADP SD", NUM2, None),
    ("adp_best", "ADP Best", INT, None),
    ("adp_worst", "ADP Worst", INT, None),
    ("ecr", "ECR", NUM2, "down"),
    ("player_owned_avg", "Rostered %", NUM1, "up"),
]

FANTASY = [
    ("y25_team", "'25 Team", None, None),
    ("y25_games", "'25 G", INT, "up"),
    ("y25_ppr_total", "'25 PPR", NUM1, "up"),
    ("y25_ppr_ppg", "'25 PPR/G", NUM2, "up"),
    ("y25_half_ppr_total", "'25 Half PPR", NUM1, "up"),
    ("y25_standard_total", "'25 Std", NUM1, "up"),
    ("y25_pos_finish", "'25 Pos Finish", INT, "down"),
    ("y25_points_per_opportunity", "'25 Pts/Opp", NUM2, "up"),
    ("y25_points_per_snap", "'25 Pts/Snap", NUM3, "up"),
]

CONSISTENCY = [
    ("y25_weekly_floor", "Floor (25th)", NUM1, "up"),
    ("y25_weekly_median", "Median Wk", NUM1, "up"),
    ("y25_weekly_ceiling", "Ceiling (85th)", NUM1, "up"),
    ("y25_boom_rate", "Boom %", PCT, "up"),
    ("y25_bust_rate", "Bust %", PCT, "down"),
    ("y25_coef_variation", "Volatility", NUM2, "down"),
]

PASSING = [
    ("y25_pass_attempts", "Pass Att", INT, "up"),
    ("completions", "Comp", INT, "up"),
    ("y25_pass_yards", "Pass Yds", INT, "up"),
    ("y25_pass_tds", "Pass TD", INT, "up"),
    ("y25_interceptions", "INT", INT, "down"),
    ("sacks_suffered", "Sacked", INT, "down"),
    ("passing_epa", "Pass EPA", NUM1, "up"),
]

RECEIVING = [
    ("y25_targets", "Tgts", INT, "up"),
    ("y25_targets_per_game", "Tgts/G", NUM1, "up"),
    ("y25_target_share_active", "Tgt Share*", PCT, "up"),
    ("y25_air_yards_share_active", "AY Share*", PCT, "up"),
    ("y25_wopr", "WOPR", NUM3, "up"),
    ("y25_receptions", "Rec", INT, "up"),
    ("y25_catch_rate", "Catch %", PCT, "up"),
    ("y25_rec_yards", "Rec Yds", INT, "up"),
    ("y25_yards_per_target", "Y/Tgt", NUM2, "up"),
    ("y25_adot", "aDOT", NUM1, None),
    ("y25_yac_per_rec", "YAC/Rec", NUM2, "up"),
    ("y25_racr", "RACR", NUM2, "up"),
    ("ngs_separation", "NGS Sep", NUM2, "up"),
    ("ngs_cushion", "NGS Cushion", NUM2, None),
    ("ngs_yac_over_expected", "YAC O/E", NUM2, "up"),
    ("rec_drop_pct", "Drop %", PCT, "down"),
]

RUSHING = [
    ("y25_carries", "Carries", INT, "up"),
    ("y25_carries_per_game", "Car/G", NUM1, "up"),
    ("y25_carry_share_active", "Carry Share*", PCT, "up"),
    ("y25_rush_yards", "Rush Yds", INT, "up"),
    ("y25_yards_per_carry", "Y/Carry", NUM2, "up"),
    ("rush_ybc_per_att", "Yds B4 Contact", NUM2, "up"),
    ("rush_yac_per_att", "Yds After Contact", NUM2, "up"),
    ("rush_broken_tackles", "Broken Tkls", INT, "up"),
    ("ngs_ryoe_per_att", "RYOE/Att", NUM2, "up"),
    ("ngs_eight_plus_box_pct", "8+ Box %", NUM1, "down"),
    ("ngs_rush_efficiency", "NGS Efficiency", NUM2, "down"),
]

RED_ZONE = [
    ("y25_rz_opportunities", "RZ Opps", INT, "up"),
    ("y25_inside_10_touches", "Inside 10", INT, "up"),
    ("y25_inside_5_touches", "Inside 5", INT, "up"),
    ("y25_total_tds", "TDs", INT, "up"),
    ("y25_expected_tds", "Expected TDs", NUM2, "up"),
    ("y25_td_over_expected", "TD Over Exp", NUM2, None),
    ("y25_td_rate_per_opp", "TD/Opp", NUM3, "up"),
]

USAGE = [
    ("y25_snaps", "Snaps", INT, "up"),
    ("y25_snap_pct", "Snap %", PCT, "up"),
    ("y25_opportunities", "Opportunities", INT, "up"),
]

TEAM = [
    ("tm_ol_overall_grade", "OL Overall", NUM1, "up"),
    ("tm_ol_run_block_grade", "OL Run Block", NUM1, "up"),
    ("tm_ol_pass_block_grade", "OL Pass Block", NUM1, "up"),
    ("tm_adjusted_line_yards", "Adj Line Yds", NUM2, "up"),
    ("tm_stuff_rate_adj", "Stuff Rate", PCT, "down"),
    ("tm_power_success", "Power Success", PCT, "up"),
    ("tm_ybc_per_att", "Team YBC/Att", NUM2, "up"),
    ("tm_pressure_rate_allowed", "Pressure Allowed", PCT, "down"),
    ("tm_sack_rate_adj", "Sack Rate Allowed", PCT, "down"),
    ("tm_avg_pocket_time", "Pocket Time", NUM2, "up"),
    ("tm_ol_continuity_pct", "OL Continuity", PCT, "up"),
    ("tm_returning_starters", "OL Starters Back", INT, "up"),
    ("tm_proe", "PROE", PCT, None),
    ("tm_neutral_pass_rate", "Neutral Pass %", PCT, None),
    ("tm_plays_per_game", "Plays/G", NUM1, "up"),
    ("tm_sec_per_play", "Sec/Play", NUM1, "down"),
    ("tm_rz_trips_per_game", "RZ Trips/G", NUM2, "up"),
    ("tm_points_per_game", "Team PPG", NUM1, "up"),
    ("tm_rush_epa_per_play", "Rush EPA/Play", NUM3, "up"),
    ("tm_pass_epa_per_play", "Pass EPA/Play", NUM3, "up"),
]

VACATED = [
    ("tm_vacated_targets", "Vacated Tgts", INT, "up"),
    ("tm_vacated_target_pct", "Vacated Tgt %", PCT, "up"),
    ("tm_vacated_carries", "Vacated Carries", INT, "up"),
    ("tm_vacated_carry_pct", "Vacated Carry %", PCT, "up"),
    ("tm_vacated_rz_touches", "Vacated RZ", INT, "up"),
]

VALUE = [
    ("value_score", "Value Score", NUM2, "up"),
    ("value_score_ppg", "Value (per game)", NUM2, "up"),
    ("market_verdict", "Verdict", None, None),
    ("notes", "Notes", None, None),
]

MASTER = (IDENTITY + MARKET + FANTASY + CONSISTENCY + USAGE + RECEIVING
          + RUSHING + RED_ZONE + TEAM + VACATED + VALUE)

POSITION_LAYOUTS = {
    "QB": IDENTITY + MARKET + FANTASY + CONSISTENCY + PASSING
          + [c for c in RUSHING if c[0] in
             ("y25_carries", "y25_carries_per_game", "y25_rush_yards",
              "y25_yards_per_carry", "ngs_ryoe_per_att")]
          + RED_ZONE + TEAM + VALUE,
    "RB": IDENTITY + MARKET + FANTASY + CONSISTENCY + USAGE + RUSHING
          + [c for c in RECEIVING if c[0] in
             ("y25_targets", "y25_targets_per_game", "y25_target_share_active",
              "y25_receptions", "y25_rec_yards", "y25_yards_per_target",
              "y25_catch_rate")]
          + RED_ZONE + TEAM + VACATED + VALUE,
    "WR": IDENTITY + MARKET + FANTASY + CONSISTENCY + USAGE + RECEIVING
          + RED_ZONE + TEAM + VACATED + VALUE,
    "TE": IDENTITY + MARKET + FANTASY + CONSISTENCY + USAGE + RECEIVING
          + RED_ZONE + TEAM + VACATED + VALUE,
}

TEAM_TAB = [
    ("team", "Team", None, None),
    ("ol_overall_grade", "OL Overall", NUM1, "up"),
    ("ol_run_block_grade", "OL Run Block", NUM1, "up"),
    ("ol_pass_block_grade", "OL Pass Block", NUM1, "up"),
    ("adjusted_line_yards", "Adj Line Yds", NUM2, "up"),
    ("raw_aly", "Raw Line Yds", NUM2, "up"),
    ("opp_faced_aly", "Opp Faced (Line Yds)", NUM2, None),
    ("stuff_rate", "Stuff Rate", PCT, "down"),
    ("stuff_rate_adj", "Stuff Rate (Adj)", PCT, "down"),
    ("power_success", "Power Success", PCT, "up"),
    ("second_level_yards", "2nd Level Yds", NUM2, "up"),
    ("open_field_yards", "Open Field Yds", NUM2, "up"),
    ("ybc_per_att", "Yds B4 Contact/Att", NUM2, "up"),
    ("pressure_rate_allowed", "Pressure Allowed", PCT, "down"),
    ("sack_rate_allowed", "Sack Rate Allowed", PCT, "down"),
    ("sack_rate_adj", "Sack Rate (Adj)", PCT, "down"),
    ("avg_pocket_time", "Pocket Time", NUM2, "up"),
    ("ol_continuity_pct", "OL Continuity", PCT, "up"),
    ("returning_starters", "Starters Back (of 5)", INT, "up"),
    ("plays_per_game", "Plays/G", NUM1, "up"),
    ("neutral_pass_rate", "Neutral Pass %", PCT, None),
    ("neutral_run_rate", "Neutral Run %", PCT, None),
    ("proe", "PROE", PCT, None),
    ("sec_per_play", "Sec/Play", NUM1, "down"),
    ("rz_trips_per_game", "RZ Trips/G", NUM2, "up"),
    ("points_per_game", "Points/G", NUM1, "up"),
    ("rush_epa_per_play", "Rush EPA/Play", NUM3, "up"),
    ("pass_epa_per_play", "Pass EPA/Play", NUM3, "up"),
    ("vacated_targets", "Vacated Tgts", INT, "up"),
    ("vacated_target_pct", "Vacated Tgt %", PCT, "up"),
    ("vacated_carries", "Vacated Carries", INT, "up"),
    ("vacated_carry_pct", "Vacated Carry %", PCT, "up"),
    ("vacated_rz_touches", "Vacated RZ Touches", INT, "up"),
]

# Columns the Master tab computes with a live formula rather than a constant,
# so the sheet still recalculates if a user edits an input.
# name -> (numerator column, denominator column)
FORMULA_RATIOS = {
    "y25_ppr_ppg": ("y25_ppr_total", "y25_games"),
    "y25_targets_per_game": ("y25_targets", "y25_games"),
    "y25_carries_per_game": ("y25_carries", "y25_games"),
    "y25_catch_rate": ("y25_receptions", "y25_targets"),
    "y25_yards_per_target": ("y25_rec_yards", "y25_targets"),
    "y25_yards_per_carry": ("y25_rush_yards", "y25_carries"),
    "y25_points_per_opportunity": ("y25_ppr_total", "y25_opportunities"),
    "y25_points_per_snap": ("y25_ppr_total", "y25_snaps"),
    "y25_td_rate_per_opp": ("y25_total_tds", "y25_opportunities"),
}

# Same idea, but a subtraction rather than a ratio.
FORMULA_DIFFS = {
    "y25_td_over_expected": ("y25_total_tds", "y25_expected_tds"),
}
