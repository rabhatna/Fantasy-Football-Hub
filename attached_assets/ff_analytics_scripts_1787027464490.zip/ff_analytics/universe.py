"""Selecting the 250 and pinning down where each of them plays in 2026."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import POSITIONS, TOP_N, STAT_SEASON, MARKET_SEASON
from .identity import norm_name, norm_team, resolve_gsis


def resolve_team_2026(gsis_ids: pd.Series, roster_mkt: pd.DataFrame,
                      depth: pd.DataFrame, players: pd.DataFrame,
                      ecr_team: pd.Series | None = None) -> pd.DataFrame:
    """Where does this player line up in 2026?

    No single source is complete. The 2026 roster file lags on veterans who
    have signed but not been processed (Stefon Diggs was missing from it on
    build day), the depth chart only lists players deep enough to be charted,
    and FantasyPros carries its own abbreviations. So: cascade, and record
    which source answered.
    """
    ros = roster_mkt.copy()
    ros["team"] = ros["team"].map(norm_team)
    ros = ros[ros["status"].isin(["ACT", "RES", "E14"])]
    ros = ros.dropna(subset=["gsis_id"]).drop_duplicates("gsis_id")
    m_roster = ros.set_index("gsis_id")["team"]

    latest = depth[depth["dt"] == depth["dt"].max()].copy()
    latest["team"] = latest["team"].map(norm_team)
    latest = latest.dropna(subset=["gsis_id"]).sort_values("pos_rank")
    m_depth = latest.drop_duplicates("gsis_id").set_index("gsis_id")["team"]
    m_depth_rank = latest.drop_duplicates("gsis_id").set_index("gsis_id")["pos_rank"]
    m_depth_slot = latest.drop_duplicates("gsis_id").set_index("gsis_id")["pos_abb"]

    pl = players.dropna(subset=["gsis_id"]).drop_duplicates("gsis_id")
    m_latest = pl.set_index("gsis_id")["latest_team"].map(norm_team)

    out = pd.DataFrame({"gsis_id": gsis_ids.values})
    out["t_roster"] = out["gsis_id"].map(m_roster)
    out["t_depth"] = out["gsis_id"].map(m_depth)
    out["t_latest"] = out["gsis_id"].map(m_latest)
    out["t_ecr"] = (out["gsis_id"].map(ecr_team).map(norm_team)
                    if ecr_team is not None else pd.NA)

    out["team_2026"] = (out["t_roster"].fillna(out["t_depth"])
                        .fillna(out["t_latest"]).fillna(out["t_ecr"]))
    out["team_source"] = np.select(
        [out["t_roster"].notna(), out["t_depth"].notna(),
         out["t_latest"].notna(), out["t_ecr"].notna()],
        ["roster_2026", "depth_chart_2026", "players_latest_team", "fantasypros"],
        default="unknown")

    out["depth_rank_2026"] = out["gsis_id"].map(m_depth_rank)
    out["depth_slot_2026"] = out["gsis_id"].map(m_depth_slot)
    return out


def build(ecr: pd.DataFrame, crosswalk: pd.DataFrame, dp_ids: pd.DataFrame,
          roster_mkt: pd.DataFrame, depth: pd.DataFrame, players: pd.DataFrame,
          top_n: int = TOP_N) -> pd.DataFrame:
    """The FantasyPros redraft board, resolved to gsis ids and 2026 teams."""
    red = ecr[(ecr["page_type"] == "redraft-overall")
              & (ecr["pos"].astype(str).str.upper().isin(POSITIONS))].copy()
    red["ecr"] = pd.to_numeric(red["ecr"], errors="coerce")
    red = red.dropna(subset=["ecr"]).sort_values("ecr")

    r = resolve_gsis(red, crosswalk, dp_ids, STAT_SEASON, MARKET_SEASON)
    r = r.drop_duplicates(subset="gsis_id", keep="first")

    teams = resolve_team_2026(r["gsis_id"], roster_mkt, depth, players,
                              ecr_team=r.set_index("gsis_id")["tm"]
                              if "tm" in r.columns else None)
    r = r.merge(teams.drop_duplicates("gsis_id"), on="gsis_id", how="left")

    r = r.sort_values("ecr").head(top_n).reset_index(drop=True)
    r["rank"] = np.arange(1, len(r) + 1)
    r["pos_rank"] = r.groupby("pos")["ecr"].rank(method="first").astype(int)
    r["pos_rank_label"] = r["pos"] + r["pos_rank"].astype(str)
    return r
