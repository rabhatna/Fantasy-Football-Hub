"""Player-level production, opportunity, efficiency and consistency.

Everything here describes the 2025 regular season. Postseason is excluded --
only 14 teams play in it, so including it would quietly reward players on good
teams in every per-game column.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import BOOM_TOP_N, CEILING_PCTL, FLOOR_PCTL, RED_ZONE_YARDLINE
from .identity import norm_team, norm_name
from .team_context import normalise_pbp, _drop_multi


def weekly_activity(weekly: pd.DataFrame, snaps: pd.DataFrame,
                    players: pd.DataFrame) -> pd.DataFrame:
    """Which (player, week) pairs did the player actually take the field for?

    Defining activity as "recorded a target or carry" quietly drops the weeks a
    player suited up and was never thrown to -- 465 such player-weeks in 2025.
    Those are real games and they belong in a floor calculation. Snap counts
    are the honest source; a touch is the fallback where snaps are missing.
    """
    xw = players[["gsis_id", "pfr_id"]].dropna().drop_duplicates("pfr_id")
    s = snaps[snaps["game_type"] == "REG"][
        ["pfr_player_id", "week", "offense_snaps"]].copy()
    s["offense_snaps"] = pd.to_numeric(s["offense_snaps"], errors="coerce").fillna(0)
    s = s.rename(columns={"pfr_player_id": "pfr_id"}).merge(xw, on="pfr_id", how="left")
    s = s.dropna(subset=["gsis_id"])
    s = s.groupby(["gsis_id", "week"], as_index=False)["offense_snaps"].sum()
    s["played_snaps"] = s["offense_snaps"] > 0
    return s[["gsis_id", "week", "offense_snaps", "played_snaps"]]


def _attach_activity(w: pd.DataFrame, activity: pd.DataFrame | None) -> pd.DataFrame:
    """Add an `active` flag: took a snap, or (fallback) recorded a touch."""
    touch = ((pd.to_numeric(w["targets"], errors="coerce").fillna(0) > 0)
             | (pd.to_numeric(w["carries"], errors="coerce").fillna(0) > 0)
             | (pd.to_numeric(w["attempts"], errors="coerce").fillna(0) > 0))
    if activity is None or activity.empty:
        w["active"] = touch.astype(int)
        return w
    a = activity.rename(columns={"gsis_id": "player_id"})
    w = w.merge(a[["player_id", "week", "played_snaps"]],
                on=["player_id", "week"], how="left")
    w["active"] = (w["played_snaps"].fillna(False) | touch).astype(int)
    return w.drop(columns=["played_snaps"])


def _reg(weekly: pd.DataFrame) -> pd.DataFrame:
    w = weekly[weekly["season_type"] == "REG"].copy()
    w["team"] = w["team"].map(norm_team)
    return w


# --------------------------------------------------------------------------
# season totals and opportunity shares
# --------------------------------------------------------------------------
SUM_COLS = [
    "completions", "attempts", "passing_yards", "passing_tds",
    "passing_interceptions", "sacks_suffered", "passing_air_yards",
    "passing_first_downs", "passing_epa", "carries", "rushing_yards",
    "rushing_tds", "rushing_first_downs", "rushing_epa", "rushing_fumbles_lost",
    "receptions", "targets", "receiving_yards", "receiving_tds",
    "receiving_air_yards", "receiving_yards_after_catch",
    "receiving_first_downs", "receiving_epa", "receiving_fumbles_lost",
    "special_teams_tds", "fantasy_points", "fantasy_points_ppr",
]


def season_totals(weekly: pd.DataFrame) -> pd.DataFrame:
    w = _reg(weekly)
    cols = [c for c in SUM_COLS if c in w.columns]
    for c in cols:
        w[c] = pd.to_numeric(w[c], errors="coerce").fillna(0)

    g = w.groupby("player_id").agg(
        {**{c: "sum" for c in cols},
         "week": "nunique", "player_display_name": "last", "position": "last"})
    g = g.rename(columns={"week": "games", "player_display_name": "name_2025"})

    # Primary 2025 team = wherever the player logged the most weeks.
    prim = (w.groupby(["player_id", "team"]).size().rename("n").reset_index()
              .sort_values("n", ascending=False)
              .drop_duplicates("player_id").set_index("player_id")["team"])
    g["team_2025"] = prim
    g["teams_2025"] = w.groupby("player_id")["team"].nunique()

    # Half-PPR sits exactly between standard and full PPR.
    g["fantasy_points_half_ppr"] = (g["fantasy_points"]
                                    + g["fantasy_points_ppr"]) / 2
    return g.reset_index().rename(columns={"player_id": "gsis_id"})


def opportunity_shares(weekly: pd.DataFrame,
                       activity: pd.DataFrame | None = None) -> pd.DataFrame:
    """Target / carry / air-yard share, computed two ways.

    `*_share` is over the team's whole season -- raw opportunity, which a
    missed month drags down. `*_share_active` is over only the weeks the
    player actually appeared, which is what carries forward to next season.
    """
    w = _reg(weekly)
    for c in ("targets", "carries", "receiving_air_yards"):
        w[c] = pd.to_numeric(w[c], errors="coerce").fillna(0)

    tw = w.groupby(["team", "week"]).agg(
        tm_targets=("targets", "sum"),
        tm_carries=("carries", "sum"),
        tm_air_yards=("receiving_air_yards", "sum"),
    ).reset_index()

    m = w.merge(tw, on=["team", "week"], how="left")
    m = _attach_activity(m, activity)

    # Full-season share. A traded player's numerator spans both teams, so the
    # denominator has to as well -- charging his combined targets against one
    # team's total inflated Jakobi Meyers from 0.11 to 0.20.
    tm_season = tw.groupby("team")[["tm_targets", "tm_carries",
                                    "tm_air_yards"]].sum()
    per_team = m.groupby(["player_id", "team"]).agg(
        p_tgt=("targets", "sum"), p_car=("carries", "sum"),
        p_ay=("receiving_air_yards", "sum")).reset_index()
    per_team = per_team.join(tm_season, on="team")
    full = per_team.groupby("player_id").agg(
        p_tgt=("p_tgt", "sum"), p_car=("p_car", "sum"), p_ay=("p_ay", "sum"),
        tm_targets=("tm_targets", "sum"), tm_carries=("tm_carries", "sum"),
        tm_air_yards=("tm_air_yards", "sum"))

    act = m[m["active"] == 1].groupby("player_id").agg(
        a_tgt=("targets", "sum"), a_car=("carries", "sum"),
        a_ay=("receiving_air_yards", "sum"),
        a_tm_tgt=("tm_targets", "sum"), a_tm_car=("tm_carries", "sum"),
        a_tm_ay=("tm_air_yards", "sum"), games_active=("active", "sum"))

    prim = (w.groupby(["player_id", "team"]).size().rename("n").reset_index()
              .sort_values("n", ascending=False)
              .drop_duplicates("player_id").set_index("player_id")["team"])

    out = full.join(act).join(prim.rename("team"))

    out["target_share"] = (out["p_tgt"] / out["tm_targets"]).round(4)
    out["carry_share"] = (out["p_car"] / out["tm_carries"]).round(4)
    out["air_yards_share"] = (out["p_ay"] / out["tm_air_yards"]).round(4)
    out["target_share_active"] = (out["a_tgt"] / out["a_tm_tgt"]).round(4)
    out["carry_share_active"] = (out["a_car"] / out["a_tm_car"]).round(4)
    out["air_yards_share_active"] = (out["a_ay"] / out["a_tm_ay"]).round(4)

    # WOPR: 1.5 x target share + 0.7 x air yards share (Josh Hermsmeyer).
    out["wopr"] = (1.5 * out["target_share_active"]
                   + 0.7 * out["air_yards_share_active"]).round(4)

    keep = ["target_share", "carry_share", "air_yards_share",
            "target_share_active", "carry_share_active",
            "air_yards_share_active", "wopr", "games_active"]
    return out[keep].reset_index().rename(columns={"player_id": "gsis_id"})


# --------------------------------------------------------------------------
# weekly shape: floor, ceiling, boom, bust
# --------------------------------------------------------------------------
def consistency(weekly: pd.DataFrame,
                activity: pd.DataFrame | None = None) -> pd.DataFrame:
    w = _reg(weekly)
    w["fantasy_points_ppr"] = pd.to_numeric(w["fantasy_points_ppr"],
                                            errors="coerce").fillna(0)
    w = w[w["position"].isin(BOOM_TOP_N.keys())].copy()

    # A "boom" week is a top-N finish at the position *that week* -- the thing
    # that actually wins a matchup, as opposed to a good season average.
    w["_rank"] = w.groupby(["week", "position"])["fantasy_points_ppr"] \
                  .rank(ascending=False, method="min")
    w["boom"] = [r <= BOOM_TOP_N.get(p, 12)
                 for r, p in zip(w["_rank"], w["position"])]

    med = w.groupby(["week", "position"])["fantasy_points_ppr"].transform("median")
    w["bust"] = w["fantasy_points_ppr"] < (0.5 * med)

    # Rate stats use only the weeks the player was on the field -- defined by
    # offensive snaps, so a game he played without a target still counts.
    w = _attach_activity(w, activity)
    played = w[w["active"] == 1]

    g = played.groupby("player_id").agg(
        weekly_floor=("fantasy_points_ppr",
                      lambda s: np.percentile(s, FLOOR_PCTL) if len(s) else np.nan),
        weekly_ceiling=("fantasy_points_ppr",
                        lambda s: np.percentile(s, CEILING_PCTL) if len(s) else np.nan),
        weekly_median=("fantasy_points_ppr", "median"),
        weekly_stdev=("fantasy_points_ppr", "std"),
        boom_weeks=("boom", "sum"),
        bust_weeks=("bust", "sum"),
        weeks_played=("fantasy_points_ppr", "size"),
    ).reset_index().rename(columns={"player_id": "gsis_id"})

    g["boom_rate"] = (g["boom_weeks"] / g["weeks_played"]).round(3)
    g["bust_rate"] = (g["bust_weeks"] / g["weeks_played"]).round(3)
    g["coef_variation"] = (g["weekly_stdev"] /
                           g["weekly_median"].replace(0, np.nan)).round(3)
    for c in ("weekly_floor", "weekly_ceiling", "weekly_median", "weekly_stdev"):
        g[c] = g[c].round(2)
    return g


# --------------------------------------------------------------------------
# red zone, goal line, and expected touchdowns
# --------------------------------------------------------------------------
def _td_probability_table(pbp: pd.DataFrame) -> dict:
    """Empirical P(touchdown | yardline, play type) from this season's plays.

    Used to build expected TDs, which is how you separate a back who scored
    twelve times on twelve carries inside the 5 from one who scored twelve
    times on breakaways. The first repeats; the second does not.
    """
    tbl = {}
    for ptype, actor, td_col in (("pass", "receiver_player_id", "pass_touchdown"),
                                 ("run", "rusher_player_id", "rush_touchdown")):
        d = pbp[(pbp["play_type"] == ptype) & pbp[actor].notna()].copy()
        d["yl"] = pd.to_numeric(d["yardline_100"], errors="coerce")
        d["bucket"] = pd.cut(d["yl"], [0, 2, 5, 10, 20, 35, 50, 100],
                             labels=False, include_lowest=True)
        tbl[ptype] = d.groupby("bucket")[td_col].mean().to_dict()
    return tbl


def red_zone(pbp: pd.DataFrame) -> pd.DataFrame:
    p = normalise_pbp(pbp)
    p = p[(p["season_type"] == "REG") & (p["two_point_attempt"] == 0)].copy()
    p["yardline_100"] = pd.to_numeric(p["yardline_100"], errors="coerce")

    probs = _td_probability_table(p)
    frames = []
    for ptype, actor, td_col, pre in (
            ("pass", "receiver_player_id", "pass_touchdown", "rec"),
            ("run", "rusher_player_id", "rush_touchdown", "rush")):
        d = p[(p["play_type"] == ptype) & p[actor].notna()].copy()
        d["bucket"] = pd.cut(d["yardline_100"], [0, 2, 5, 10, 20, 35, 50, 100],
                             labels=False, include_lowest=True)
        d["xtd"] = d["bucket"].map(probs[ptype])
        g = d.groupby(actor).agg(**{
            f"{pre}_rz_opp": ("yardline_100", lambda s: int((s <= RED_ZONE_YARDLINE).sum())),
            f"{pre}_inside10": ("yardline_100", lambda s: int((s <= 10).sum())),
            f"{pre}_inside5": ("yardline_100", lambda s: int((s <= 5).sum())),
            f"{pre}_tds": (td_col, "sum"),
            f"{pre}_xtds": ("xtd", "sum"),
        })
        g.index.name = "gsis_id"
        frames.append(g)

    rz = frames[0].join(frames[1], how="outer").fillna(0).reset_index()
    rz["rz_opportunities"] = rz["rec_rz_opp"] + rz["rush_rz_opp"]
    rz["inside_10_touches"] = rz["rec_inside10"] + rz["rush_inside10"]
    rz["inside_5_touches"] = rz["rec_inside5"] + rz["rush_inside5"]
    rz["total_tds"] = rz["rec_tds"] + rz["rush_tds"]
    rz["expected_tds"] = (rz["rec_xtds"] + rz["rush_xtds"]).round(2)
    rz["td_over_expected"] = (rz["total_tds"] - rz["expected_tds"]).round(2)
    return rz


# --------------------------------------------------------------------------
# snaps, Next Gen Stats, PFR advanced
# --------------------------------------------------------------------------
def snap_share(snaps: pd.DataFrame, players: pd.DataFrame) -> pd.DataFrame:
    s = snaps[snaps["game_type"] == "REG"].copy()
    s["offense_snaps"] = pd.to_numeric(s["offense_snaps"], errors="coerce").fillna(0)
    s["offense_pct"] = pd.to_numeric(s["offense_pct"], errors="coerce")
    g = s.groupby("pfr_player_id").agg(
        offense_snaps=("offense_snaps", "sum"),
        snap_pct_avg=("offense_pct", "mean"),
        snap_games=("offense_snaps", "size"),
    ).reset_index().rename(columns={"pfr_player_id": "pfr_id"})
    g["snap_pct_avg"] = g["snap_pct_avg"].round(3)
    xw = players[["gsis_id", "pfr_id"]].dropna().drop_duplicates("pfr_id")
    return g.merge(xw, on="pfr_id", how="left")


def ngs_season(ngs_rec: pd.DataFrame, ngs_rush: pd.DataFrame,
               season: int) -> pd.DataFrame:
    """Next Gen Stats ships week 0 as the season roll-up."""
    rec = ngs_rec[(ngs_rec["season"] == season) & (ngs_rec["week"] == 0)][[
        "player_gsis_id", "avg_separation", "avg_cushion",
        "avg_intended_air_yards", "percent_share_of_intended_air_yards",
        "avg_yac_above_expectation", "catch_percentage"]].copy()
    rec.columns = ["gsis_id", "ngs_separation", "ngs_cushion", "ngs_adot",
                   "ngs_intended_air_yards_share", "ngs_yac_over_expected",
                   "ngs_catch_pct"]

    rush = ngs_rush[(ngs_rush["season"] == season) & (ngs_rush["week"] == 0)][[
        "player_gsis_id", "efficiency", "percent_attempts_gte_eight_defenders",
        "avg_time_to_los", "rush_yards_over_expected",
        "rush_yards_over_expected_per_att", "rush_pct_over_expected"]].copy()
    rush.columns = ["gsis_id", "ngs_rush_efficiency", "ngs_eight_plus_box_pct",
                    "ngs_time_to_los", "ngs_ryoe", "ngs_ryoe_per_att",
                    "ngs_rush_pct_over_expected"]

    return rec.merge(rush, on="gsis_id", how="outer")


def pfr_advanced(adv_rush: pd.DataFrame, adv_rec: pd.DataFrame,
                 players: pd.DataFrame, season: int) -> pd.DataFrame:
    xw = players[["gsis_id", "pfr_id"]].dropna().drop_duplicates("pfr_id")

    # A traded player has one PFR row per team. Averaging the per-attempt
    # rates unweighted is wrong (Tank Bigsby: mean of 1.2 and 3.1 = 2.15, when
    # the real figure is 188 yards over 63 carries = 2.98). Sum the counting
    # stats, then divide.
    ru = _drop_multi(adv_rush[adv_rush["season"] == season], "tm").copy()
    for c in ("att", "yds", "ybc", "yac", "brk_tkl"):
        if c in ru.columns:
            ru[c] = pd.to_numeric(ru[c], errors="coerce")
    ru = ru.groupby("pfr_id").agg(
        _att=("att", "sum"), _ybc=("ybc", "sum"), _yac=("yac", "sum"),
        rush_broken_tackles=("brk_tkl", "sum")).reset_index()
    ru["rush_ybc_per_att"] = (ru["_ybc"] / ru["_att"].replace(0, np.nan)).round(3)
    ru["rush_yac_per_att"] = (ru["_yac"] / ru["_att"].replace(0, np.nan)).round(3)
    ru["rush_att_per_broken"] = (ru["_att"] /
                                 ru["rush_broken_tackles"].replace(0, np.nan)).round(2)
    ru = ru.drop(columns=["_ybc", "_yac"]).rename(columns={"_att": "pfr_rush_att"})

    re_ = _drop_multi(adv_rec[adv_rec["season"] == season], "tm").copy()
    for c in ("tgt", "rec", "ybc", "yac", "adot", "brk_tkl", "drop"):
        if c in re_.columns:
            re_[c] = pd.to_numeric(re_[c], errors="coerce")
    re_["_adot_w"] = re_["adot"] * re_["tgt"]
    re_ = re_.groupby("pfr_id").agg(
        _tgt=("tgt", "sum"), _rec=("rec", "sum"), _ybc=("ybc", "sum"),
        _yac=("yac", "sum"), _adotw=("_adot_w", "sum"),
        rec_broken_tackles=("brk_tkl", "sum"), rec_drops=("drop", "sum")).reset_index()
    re_["rec_ybc_per_rec"] = (re_["_ybc"] / re_["_rec"].replace(0, np.nan)).round(3)
    re_["rec_yac_per_rec"] = (re_["_yac"] / re_["_rec"].replace(0, np.nan)).round(3)
    re_["rec_adot"] = (re_["_adotw"] / re_["_tgt"].replace(0, np.nan)).round(2)
    re_["rec_drop_pct"] = (re_["rec_drops"] / re_["_tgt"].replace(0, np.nan)).round(4)
    re_ = re_.drop(columns=["_rec", "_ybc", "_yac", "_adotw"]).rename(
        columns={"_tgt": "pfr_targets"})

    return ru.merge(re_, on="pfr_id", how="outer").merge(xw, on="pfr_id", how="left")


# --------------------------------------------------------------------------
# vacated opportunity
# --------------------------------------------------------------------------
def vacated_opportunity(weekly: pd.DataFrame, team_2026: pd.Series,
                        pbp: pd.DataFrame) -> pd.DataFrame:
    """2025 volume that belongs to nobody in 2026.

    For each team, sum the targets and carries produced by players who are not
    on that team's 2026 roster. This is the column that finds a breakout before
    the draft market prices it -- somebody has to absorb those touches.
    """
    w = _reg(weekly)
    for c in ("targets", "carries"):
        w[c] = pd.to_numeric(w[c], errors="coerce").fillna(0)

    # `team_2026` must cover every 2025 producer, not just the draft board.
    # Mapping only the top 250 books every unranked contributor as departed --
    # it booked 71% of the league's "vacated" targets against players nobody
    # said had left. Unknown is treated as retained: the conservative default.
    w["team_2026"] = w["player_id"].map(team_2026)
    w["still_here"] = (w["team_2026"] == w["team"]) | w["team_2026"].isna()

    # Red-zone touches carry more fantasy weight than raw volume, so track
    # those separately rather than burying them in the totals.
    p = normalise_pbp(pbp)
    p = p[(p["season_type"] == "REG")
          & (p["yardline_100"] <= RED_ZONE_YARDLINE)
          & (p["two_point_attempt"] == 0)
          & p["play_type"].isin(["pass", "run"])]
    rz_rows = []
    for actor in ("receiver_player_id", "rusher_player_id"):
        d = p[p[actor].notna()][["posteam", actor]].rename(
            columns={actor: "player_id", "posteam": "team"})
        rz_rows.append(d)
    rz = pd.concat(rz_rows)
    rz["team_2026"] = rz["player_id"].map(team_2026)
    rz["still_here"] = (rz["team_2026"] == rz["team"]) | rz["team_2026"].isna()

    gone = w[~w["still_here"]].groupby("team").agg(
        vacated_targets=("targets", "sum"),
        vacated_carries=("carries", "sum")).reset_index()
    tot = w.groupby("team").agg(
        team_targets_2025=("targets", "sum"),
        team_carries_2025=("carries", "sum")).reset_index()
    rz_gone = rz[~rz["still_here"]].groupby("team").size().rename(
        "vacated_rz_touches").reset_index()
    rz_tot = rz.groupby("team").size().rename("team_rz_touches_2025").reset_index()

    out = (tot.merge(gone, on="team", how="left")
              .merge(rz_tot, on="team", how="left")
              .merge(rz_gone, on="team", how="left").fillna(0))
    out["vacated_target_pct"] = (out["vacated_targets"]
                                 / out["team_targets_2025"]).round(3)
    out["vacated_carry_pct"] = (out["vacated_carries"]
                                / out["team_carries_2025"]).round(3)
    out["vacated_rz_pct"] = (out["vacated_rz_touches"]
                             / out["team_rz_touches_2025"]).round(3)
    return out
