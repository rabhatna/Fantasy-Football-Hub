"""Central configuration for the Top-250 fantasy analytics build."""
from pathlib import Path

# ---- Seasons -------------------------------------------------------------
STAT_SEASON = 2025      # season the production stats come from
MARKET_SEASON = 2026    # season the ADP / rosters / depth charts come from

# ---- Universe ------------------------------------------------------------
POSITIONS = ("QB", "RB", "WR", "TE")
TOP_N = 250

# ---- Scoring -------------------------------------------------------------
# nflverse ships fantasy_points (standard) and fantasy_points_ppr already.
# Half-PPR is derived as the midpoint. Superflex is a ranking concept, not a
# scoring one, so it is not computed here.
SCORING_FORMATS = ("ppr", "half_ppr", "standard")
PRIMARY_SCORING = "ppr"

# ---- Thresholds ----------------------------------------------------------
MIN_GAMES_FOR_RATES = 4        # below this, per-game rate stats are unreliable
MIN_TARGETS_FOR_RATES = 10     # a 50% drop rate on 2 targets is noise, not data
MIN_CARRIES_FOR_RATES = 20
BOOM_TOP_N = {"QB": 12, "RB": 12, "WR": 12, "TE": 6}
FLOOR_PCTL = 25
CEILING_PCTL = 85
FUZZY_MATCH_THRESHOLD = 92

# ---- Red zone ------------------------------------------------------------
RED_ZONE_YARDLINE = 20

# ---- O-line --------------------------------------------------------------
OL_POSITIONS = ("C", "G", "T", "OL", "OG", "OT", "LT", "RT", "LG", "RG")
# Football Outsiders Adjusted Line Yards credit schedule
ALY_BUCKETS = (
    (-99, -1, 1.20),   # losses -> 120% credited to the line
    (0, 4, 1.00),      # 0-4 yards -> 100%
    (5, 10, 0.50),     # 5-10 yards -> 50%
    (11, 999, 0.00),   # 11+ yards -> 0% (that's the runner)
)
# Run-block composite weights
RUN_BLOCK_WEIGHTS = {"aly": 0.40, "stuff": 0.20, "power": 0.15, "ybc": 0.25}
# Pass-block composite weights
PASS_BLOCK_WEIGHTS = {"pressure": 0.45, "sack": 0.35, "pocket": 0.20}

# ---- Cache ---------------------------------------------------------------
CACHE_DIR = Path.home() / ".ff_cache"
CACHE_TTL_HOURS = 24

# ---- Source URLs ---------------------------------------------------------
NFLVERSE = "https://github.com/nflverse/nflverse-data/releases/download"
DP_RAW = "https://raw.githubusercontent.com/dynastyprocess/data/master/files"
NFLDATA_RAW = "https://raw.githubusercontent.com/nflverse/nfldata/master/data"

SOURCES = {
    "weekly":       f"{NFLVERSE}/stats_player/stats_player_week_{STAT_SEASON}.parquet",
    "pbp":          f"{NFLVERSE}/pbp/play_by_play_{STAT_SEASON}.parquet",
    "snaps":        f"{NFLVERSE}/snap_counts/snap_counts_{STAT_SEASON}.parquet",
    "ngs_rec":      f"{NFLVERSE}/nextgen_stats/ngs_receiving.parquet",
    "ngs_rush":     f"{NFLVERSE}/nextgen_stats/ngs_rushing.parquet",
    "adv_rush":     f"{NFLVERSE}/pfr_advstats/advstats_season_rush.parquet",
    "adv_pass":     f"{NFLVERSE}/pfr_advstats/advstats_season_pass.parquet",
    "adv_rec":      f"{NFLVERSE}/pfr_advstats/advstats_season_rec.parquet",
    "players":      f"{NFLVERSE}/players/players.parquet",
    "roster_stat":  f"{NFLVERSE}/rosters/roster_{STAT_SEASON}.parquet",
    "roster_mkt":   f"{NFLVERSE}/rosters/roster_{MARKET_SEASON}.parquet",
    "depth_mkt":    f"{NFLVERSE}/depth_charts/depth_charts_{MARKET_SEASON}.parquet",
    "fp_ecr":       f"{DP_RAW}/db_fpecr_latest.csv",
    "dp_values":    f"{DP_RAW}/values-players.csv",
    "dp_ids":       f"{DP_RAW}/db_playerids.csv",
    "games":        f"{NFLDATA_RAW}/games.csv",
}

# Live ADP endpoints. Blocked in restricted sandboxes; tried opportunistically.
LIVE_ADP_SOURCES = [
    ("fantasyfootballcalculator",
     f"https://fantasyfootballcalculator.com/api/v1/adp/ppr?teams=12&year={MARKET_SEASON}"),
    ("sleeper", "https://api.sleeper.app/v1/players/nfl"),
]

# Team abbreviation normalisation (historical -> current nflverse standard)
TEAM_FIXES = {
    "OAK": "LV", "SD": "LAC", "AZ": "ARI", "STL": "LAR", "LA": "LAR",
    "WSH": "WAS", "ARZ": "ARI", "BLT": "BAL", "CLV": "CLE",
    "HST": "HOU", "SL": "LAR", "JAC": "JAX",
    # FantasyPros uses three-letter codes for a subset of teams.
    "SFO": "SF", "NEP": "NE", "LVR": "LV", "KCC": "KC", "GBP": "GB",
    "TBB": "TB", "NOS": "NO", "SFA": "SF", "JAG": "JAX",
}
