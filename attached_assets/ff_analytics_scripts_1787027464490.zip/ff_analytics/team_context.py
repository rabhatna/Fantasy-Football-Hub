"""Team-level context: offensive line quality and offensive environment.

Nobody publishes free O-line grades -- ESPN's block win rates and PFF's grades
are both paywalled -- so we compute them from play-by-play using the public
Football Outsiders methodology. See the Methodology tab for the formulas.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import (ALY_BUCKETS, RUN_BLOCK_WEIGHTS, PASS_BLOCK_WEIGHTS,
                     RED_ZONE_YARDLINE)
from .identity import norm_team, norm_name


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
MULTI_TEAM = {"2TM", "3TM", "4TM", ""}


def normalise_pbp(pbp: pd.DataFrame) -> pd.DataFrame:
    """Fold historical/alternate team codes (LA -> LAR, AZ -> ARI) up front.

    Doing this after the merges silently produces 34 'teams'. Do it once here.
    """
    p = pbp.copy()
    for col in ("posteam", "defteam", "home_team", "away_team"):
        if col in p.columns:
            p[col] = p[col].map(norm_team)
    return p


def _drop_multi(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """Remove Pro-Football-Reference's '2TM' rows for players who were traded.

    Their combined line cannot be attributed to either team, so including it
    would double-count. The player-level stats still capture the production.
    """
    return df[~df[col].astype(str).str.upper().isin(MULTI_TEAM)]


def _z(s: pd.Series) -> pd.Series:
    s = pd.to_numeric(s, errors="coerce")
    sd = s.std(ddof=0)
    return (s - s.mean()) / sd if sd and sd > 0 else s * 0.0


def _grade(z: pd.Series) -> pd.Series:
    """Map a z-score to a readable 0-100 scale (50 = league average)."""
    return (50 + 15 * z).clip(0, 100).round(1)


def _line_credit(yards: pd.Series) -> pd.Series:
    """Football Outsiders Adjusted Line Yards credit schedule.

    A 3-yard gain is the line's doing; a 40-yard gain is the running back's.
    Losses are charged at 120% because a run stopped behind the line is almost
    always a blocking failure.

        loss      -> 120% of the (negative) yardage
        0-4 yds   -> 100%
        5-10 yds  -> the first 4 at 100%, the rest at 50%
        11+ yds   -> capped at 4 + (6 x 0.5) = 7.0
    """
    y = pd.to_numeric(yards, errors="coerce").fillna(0).astype(float)
    credit = pd.Series(0.0, index=y.index, dtype=float)

    loss = y < 0
    credit[loss] = y[loss] * 1.20

    short = (y >= 0) & (y <= 4)
    credit[short] = y[short] * 1.00

    mid = (y >= 5) & (y <= 10)
    credit[mid] = 4.0 + (y[mid] - 4.0) * 0.50

    big = y >= 11
    credit[big] = 4.0 + 6.0 * 0.50

    return credit


# --------------------------------------------------------------------------
# rushing / run blocking
# --------------------------------------------------------------------------
def _rb_ids(players: pd.DataFrame) -> set:
    return set(players.loc[players["position"].isin(["RB", "FB", "HB"]),
                           "gsis_id"].dropna())


def run_block(pbp: pd.DataFrame, players: pd.DataFrame) -> pd.DataFrame:
    """Adjusted line yards and companion run-blocking metrics, per team."""
    rb = _rb_ids(players)
    r = pbp[(pbp["season_type"] == "REG")
            & (pbp["play_type"] == "run")
            & (pbp["rush_attempt"] == 1)
            & (pbp["qb_scramble"] != 1)
            & (pbp["two_point_attempt"] == 0)
            & pbp["posteam"].notna()
            & pbp["rusher_player_id"].isin(rb)].copy()

    r["yards_gained"] = pd.to_numeric(r["yards_gained"], errors="coerce").fillna(0)
    r["credit"] = _line_credit(r["yards_gained"])
    r["stuffed"] = (r["yards_gained"] <= 0).astype(int)
    r["second_level"] = (r["yards_gained"] - 4).clip(0, 6)
    r["open_field"] = (r["yards_gained"] - 10).clip(lower=0)

    # Power situations: 3rd/4th and <=2, or goal-to-go inside the 2.
    r["power_att"] = (((r["down"].isin([3, 4])) & (r["ydstogo"] <= 2))
                      | ((r["goal_to_go"] == 1) & (r["yardline_100"] <= 2))
                      ).astype(int)
    r["power_conv"] = (r["power_att"].astype(bool)
                       & ((r["yards_gained"] >= r["ydstogo"])
                          | (r["rush_touchdown"] == 1))).astype(int)

    off = r.groupby("posteam").agg(
        rush_att=("credit", "size"),
        raw_aly=("credit", "mean"),
        stuff_rate=("stuffed", "mean"),
        second_level_yards=("second_level", "mean"),
        open_field_yards=("open_field", "mean"),
        power_att=("power_att", "sum"),
        power_conv=("power_conv", "sum"),
        ypc=("yards_gained", "mean"),
    )
    off["power_success"] = np.where(off["power_att"] > 0,
                                    off["power_conv"] / off["power_att"], np.nan)

    # Opponent adjustment: a line that faced the league's stingiest run fronts
    # should not be punished for it. Additive shift against the league mean.
    dfn = r.groupby("defteam")["credit"].mean().rename("def_aly")
    league = r["credit"].mean()
    faced = r.groupby("posteam")["defteam"].apply(lambda s: dfn.reindex(s).mean())
    off["opp_faced_aly"] = faced
    off["adjusted_line_yards"] = (off["raw_aly"] + (league - off["opp_faced_aly"])).round(3)

    # Also opponent-adjust stuff rate.
    dstuff = r.groupby("defteam")["stuffed"].mean()
    faced_stuff = r.groupby("posteam")["defteam"].apply(lambda s: dstuff.reindex(s).mean())
    off["stuff_rate_adj"] = (off["stuff_rate"] + (r["stuffed"].mean() - faced_stuff)).round(4)

    return off.reset_index().rename(columns={"posteam": "team"})


# --------------------------------------------------------------------------
# pass blocking
# --------------------------------------------------------------------------
def pass_block(pbp: pd.DataFrame, adv_pass: pd.DataFrame, season: int) -> pd.DataFrame:
    d = pbp[(pbp["season_type"] == "REG")
            & (pbp["qb_dropback"] == 1)
            & (pbp["two_point_attempt"] == 0)
            & pbp["posteam"].notna()].copy()
    d["sack"] = pd.to_numeric(d["sack"], errors="coerce").fillna(0)

    out = d.groupby("posteam").agg(
        dropbacks=("sack", "size"),
        sack_rate_allowed=("sack", "mean"),
    ).reset_index().rename(columns={"posteam": "team"})

    # Opponent adjustment against each defense's sack rate generated.
    dsack = d.groupby("defteam")["sack"].mean()
    faced = d.groupby("posteam")["defteam"].apply(lambda s: dsack.reindex(s).mean())
    out["sack_rate_adj"] = (out["sack_rate_allowed"]
                            + (d["sack"].mean() - out["team"].map(faced))).round(4)

    # Pressure and pocket time come from PFR advanced passing, rolled up to team.
    ap = adv_pass[adv_pass["season"] == season].copy()
    ap = _drop_multi(ap, "team")
    if not ap.empty:
        ap["team"] = ap["team"].map(norm_team)
        ap["pass_attempts"] = pd.to_numeric(ap["pass_attempts"], errors="coerce")
        ap["times_pressured"] = pd.to_numeric(ap["times_pressured"], errors="coerce")
        ap["pocket_time"] = pd.to_numeric(ap["pocket_time"], errors="coerce")
        ap["_pt_w"] = ap["pocket_time"] * ap["pass_attempts"]
        agg = ap.groupby("team").agg(
            att=("pass_attempts", "sum"),
            pressured=("times_pressured", "sum"),
            pt_w=("_pt_w", "sum"),
        ).reset_index()
        agg["pressure_rate_allowed"] = (agg["pressured"] / agg["att"]).round(4)
        agg["avg_pocket_time"] = (agg["pt_w"] / agg["att"]).round(3)
        out = out.merge(agg[["team", "pressure_rate_allowed", "avg_pocket_time"]],
                        on="team", how="left")
    else:
        out["pressure_rate_allowed"] = np.nan
        out["avg_pocket_time"] = np.nan
    return out


# --------------------------------------------------------------------------
# offensive environment
# --------------------------------------------------------------------------
def offense_environment(pbp: pd.DataFrame) -> pd.DataFrame:
    p = pbp[(pbp["season_type"] == "REG") & pbp["posteam"].notna()].copy()
    scrim = p[p["play_type"].isin(["pass", "run"])].copy()
    scrim["is_pass"] = (scrim["play_type"] == "pass").astype(int)
    scrim["epa"] = pd.to_numeric(scrim["epa"], errors="coerce")

    games = scrim.groupby("posteam")["game_id"].nunique().rename("games")

    base = scrim.groupby("posteam").agg(
        plays=("is_pass", "size"),
        pass_rate=("is_pass", "mean"),
    )
    base = base.join(games)
    base["plays_per_game"] = (base["plays"] / base["games"]).round(2)

    # Situation-neutral: win probability 20-80%, first three downs, outside
    # the two-minute drills. This is where a coach's actual tendency shows.
    neu = scrim[(scrim["wp"].between(0.2, 0.8))
                & (scrim["down"].isin([1, 2, 3]))
                & (scrim["half_seconds_remaining"] > 120)]
    base["neutral_pass_rate"] = neu.groupby("posteam")["is_pass"].mean().round(4)
    base["neutral_run_rate"] = (1 - base["neutral_pass_rate"]).round(4)

    # PROE -- pass rate over expected, from nflverse's xpass model.
    if "pass_oe" in scrim.columns:
        base["proe"] = (scrim.groupby("posteam")["pass_oe"].mean() / 100).round(4)
    else:
        base["proe"] = np.nan

    base["rush_epa_per_play"] = scrim[scrim["is_pass"] == 0].groupby(
        "posteam")["epa"].mean().round(4)
    base["pass_epa_per_play"] = scrim[scrim["is_pass"] == 1].groupby(
        "posteam")["epa"].mean().round(4)

    # Pace: seconds of game clock burned per offensive snap, situation-neutral.
    pace = neu.copy()
    pace = pace.sort_values(["game_id", "fixed_drive", "play_id"]) \
        if "play_id" in pace.columns else pace
    pace["gap"] = pace.groupby(["game_id", "fixed_drive"])[
        "game_seconds_remaining"].diff(-1)
    base["sec_per_play"] = pace[pace["gap"].between(1, 60)].groupby(
        "posteam")["gap"].median().round(1)

    # Red-zone trips per game (unique drives reaching the 20).
    rz = p[(p["yardline_100"] <= RED_ZONE_YARDLINE)
           & p["play_type"].isin(["pass", "run", "field_goal"])]
    trips = rz.groupby("posteam").apply(
        lambda d: d.groupby(["game_id", "fixed_drive"]).ngroups,
        include_groups=False).rename("rz_trips")
    base = base.join(trips)
    base["rz_trips_per_game"] = (base["rz_trips"] / base["games"]).round(2)

    # Team scoring, taken from the final score of each game.
    fin = p.dropna(subset=["posteam"]).groupby(["posteam", "game_id"]).agg(
        pts=("posteam_score_post", "max")) if "posteam_score_post" in p.columns else None
    if fin is not None:
        base["points_per_game"] = fin.groupby("posteam")["pts"].mean().round(1)

    return base.reset_index().rename(columns={"posteam": "team"})


# --------------------------------------------------------------------------
# O-line continuity: does the 2025 line actually return in 2026?
# --------------------------------------------------------------------------
def ol_continuity(snaps: pd.DataFrame, depth: pd.DataFrame,
                  roster_mkt: pd.DataFrame) -> pd.DataFrame:
    """A 2025 line grade only transfers if the same bodies are still there.

    Snap-weighted: of the offensive-line snaps a team played in 2025, what
    share were played by men who are on the 2026 roster?
    """
    ol_snaps = snaps[(snaps["game_type"] == "REG")
                     & snaps["position"].isin(["T", "G", "C", "OL"])].copy()
    ol_snaps["team"] = ol_snaps["team"].map(norm_team)
    ol_snaps["offense_snaps"] = pd.to_numeric(ol_snaps["offense_snaps"],
                                              errors="coerce").fillna(0)
    by_player = ol_snaps.groupby(["team", "player", "pfr_player_id"],
                                 as_index=False)["offense_snaps"].sum()
    by_player["mname"] = by_player["player"].map(norm_name)

    ros = roster_mkt.copy()
    ros["team"] = ros["team"].map(norm_team)
    ros["mname"] = ros["full_name"].map(norm_name)
    ros_keys = set(zip(ros["team"], ros["mname"]))
    ros_names = set(ros["mname"])

    by_player["returns_same_team"] = [
        (t, n) in ros_keys for t, n in zip(by_player["team"], by_player["mname"])]
    by_player["returns_anywhere"] = by_player["mname"].isin(ros_names)

    g = by_player.groupby("team").agg(
        ol_snaps_2025=("offense_snaps", "sum"),
        ol_snaps_returning=("offense_snaps",
                            lambda s: s[by_player.loc[s.index, "returns_same_team"]].sum()),
    ).reset_index()
    g["ol_continuity_pct"] = (g["ol_snaps_returning"] / g["ol_snaps_2025"]).round(3)

    # How many of the five projected 2026 starters logged 2025 snaps here?
    latest = depth[depth["dt"] == depth["dt"].max()]
    starters = latest[(latest["pos_abb"].isin(["LT", "LG", "C", "RG", "RT"]))
                      & (latest["pos_rank"] == 1)].copy()
    starters["team"] = starters["team"].map(norm_team)
    starters["mname"] = starters["player_name"].map(norm_name)
    prev = {(t, n) for t, n in zip(by_player["team"], by_player["mname"])
            if by_player.loc[(by_player["team"] == t)
                             & (by_player["mname"] == n), "offense_snaps"].max() >= 200}
    starters["returning"] = [(t, n) in prev
                             for t, n in zip(starters["team"], starters["mname"])]
    s = starters.groupby("team").agg(
        proj_starters=("returning", "size"),
        returning_starters=("returning", "sum"),
    ).reset_index()

    return g.merge(s, on="team", how="outer")


# --------------------------------------------------------------------------
# assembly
# --------------------------------------------------------------------------
def team_ybc(adv_rush: pd.DataFrame, season: int) -> pd.DataFrame:
    """Team yards before contact per attempt -- the cleanest single line proxy."""
    a = adv_rush[adv_rush["season"] == season].copy()
    a = _drop_multi(a, "tm")
    if a.empty:
        return pd.DataFrame(columns=["team", "ybc_per_att", "yac_per_att",
                                     "broken_tackles"])
    a["team"] = a["tm"].map(norm_team)
    for c in ("att", "ybc", "yac", "brk_tkl"):
        a[c] = pd.to_numeric(a[c], errors="coerce")
    g = a.groupby("team").agg(att=("att", "sum"), ybc=("ybc", "sum"),
                              yac=("yac", "sum"), brk=("brk_tkl", "sum")).reset_index()
    g["ybc_per_att"] = (g["ybc"] / g["att"]).round(3)
    g["yac_per_att"] = (g["yac"] / g["att"]).round(3)
    g["broken_tackles"] = g["brk"]
    return g[["team", "ybc_per_att", "yac_per_att", "broken_tackles"]]


def build(pbp, players, adv_pass, adv_rush, snaps, depth, roster_mkt, season) -> pd.DataFrame:
    pbp = normalise_pbp(pbp)
    rb = run_block(pbp, players)
    ybc = team_ybc(adv_rush, season)
    pb = pass_block(pbp, adv_pass, season)
    env = offense_environment(pbp)
    cont = ol_continuity(snaps, depth, roster_mkt)

    t = rb.merge(ybc, on="team", how="outer") \
          .merge(pb, on="team", how="outer") \
          .merge(env, on="team", how="outer") \
          .merge(cont, on="team", how="outer")
    t["team"] = t["team"].map(norm_team)

    # Composite run-block grade. Stuff rate is inverted -- fewer is better.
    z_run = (RUN_BLOCK_WEIGHTS["aly"] * _z(t["adjusted_line_yards"])
             + RUN_BLOCK_WEIGHTS["stuff"] * -_z(t["stuff_rate_adj"])
             + RUN_BLOCK_WEIGHTS["power"] * _z(t["power_success"])
             + RUN_BLOCK_WEIGHTS["ybc"] * _z(t["ybc_per_att"]))
    t["_z_run_partial"] = z_run
    t["ol_run_block_grade"] = _grade(_z(z_run))

    # Composite pass-block grade. Pressure and sacks inverted.
    z_pass = (PASS_BLOCK_WEIGHTS["pressure"] * -_z(t["pressure_rate_allowed"])
              + PASS_BLOCK_WEIGHTS["sack"] * -_z(t["sack_rate_adj"])
              + PASS_BLOCK_WEIGHTS["pocket"] * _z(t["avg_pocket_time"]))
    t["ol_pass_block_grade"] = _grade(_z(z_pass))

    t["ol_overall_grade"] = _grade(_z(_z(t["ol_run_block_grade"])
                                      + _z(t["ol_pass_block_grade"])))
    return t
