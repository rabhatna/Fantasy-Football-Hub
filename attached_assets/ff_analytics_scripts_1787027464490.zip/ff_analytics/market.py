"""Draft-market data: ADP where we can get it, expert consensus otherwise."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .identity import norm_name, norm_team


def attach_adp(universe: pd.DataFrame, adp: pd.DataFrame,
               source_name: str) -> pd.DataFrame:
    """Layer real ADP over the ECR board.

    ECR and ADP are not the same thing -- experts rank, drafters draft, and
    the gap between them is often where the value is. When a live ADP feed is
    reachable we keep both and expose the disagreement. When it is not, ECR
    stands in and every row says so in `adp_source`.
    """
    u = universe.copy()
    u["merge_name"] = u["player"].map(norm_name)
    u["_pos"] = u["position"].astype(str).str.upper()

    if adp is None or adp.empty:
        u["adp"] = u["ecr"]
        u["adp_stdev"] = pd.to_numeric(u.get("sd"), errors="coerce")
        u["adp_best"] = pd.to_numeric(u.get("best"), errors="coerce")
        u["adp_worst"] = pd.to_numeric(u.get("worst"), errors="coerce")
        u["adp_source"] = "fantasypros_ecr"
        u["adp_vs_ecr_gap"] = 0.0
        return u.drop(columns=["_pos"])

    a = adp.copy()
    a["merge_name"] = a["player"].map(norm_name)
    a["_pos"] = a["pos"].astype(str).str.upper()
    a = a.drop_duplicates(subset=["merge_name", "_pos"])
    cols = [c for c in ("adp", "adp_stdev", "adp_best", "adp_worst",
                        "adp_times_drafted") if c in a.columns]
    u = u.merge(a[["merge_name", "_pos"] + cols], on=["merge_name", "_pos"],
                how="left")

    u["adp_source"] = np.where(u["adp"].notna(), source_name, "fantasypros_ecr")
    # ECR fills the gaps so the column is never empty for a top-250 player.
    u["adp"] = u["adp"].fillna(u["ecr"])
    for src, dst in (("sd", "adp_stdev"), ("best", "adp_best"),
                     ("worst", "adp_worst")):
        if dst not in u.columns:
            u[dst] = np.nan
        u[dst] = u[dst].fillna(pd.to_numeric(u.get(src), errors="coerce"))

    # Positive gap = drafters are taking him later than the experts rank him.
    u["adp_vs_ecr_gap"] = (u["adp"] - u["ecr"]).round(2)
    return u.drop(columns=["_pos"])


def value_scores(df: pd.DataFrame) -> pd.DataFrame:
    """Where last year's production and this year's price disagree."""
    d = df.copy()

    def z(s):
        s = pd.to_numeric(s, errors="coerce")
        sd = s.std(ddof=0)
        return (s - s.mean()) / sd if sd and sd > 0 else s * 0.0

    # Rank last season's PPR finish within position, so a QB is compared to
    # QBs. Then compare that to where the market is drafting him.
    d["y25_pos_finish"] = d.groupby("position")["y25_ppr_total"].rank(
        ascending=False, method="min")
    d["y26_adp_pos_rank"] = d.groupby("position")["adp"].rank(method="min")

    # Lower rank number = better, so flip the sign on both.
    d["value_score"] = (-z(d["y25_pos_finish"]) + z(d["y26_adp_pos_rank"])).round(3)

    # Per-game production is the fairer comparison for anyone who missed time.
    d["y25_ppg_pos_finish"] = d.groupby("position")["y25_ppr_ppg"].rank(
        ascending=False, method="min")
    d["value_score_ppg"] = (-z(d["y25_ppg_pos_finish"])
                            + z(d["y26_adp_pos_rank"])).round(3)

    d["market_verdict"] = pd.cut(
        d["value_score"], [-np.inf, -1.0, -0.35, 0.35, 1.0, np.inf],
        labels=["Overpriced", "Slight reach", "Fairly priced",
                "Slight value", "Underpriced"])
    return d
