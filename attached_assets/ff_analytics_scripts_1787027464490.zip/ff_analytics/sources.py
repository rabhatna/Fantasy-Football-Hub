"""Data acquisition with an on-disk parquet cache.

Every source is free and unauthenticated. The play-by-play file is large
(~100MB), so the cache is what makes iterating on this build tolerable.
"""
from __future__ import annotations

import io
import json
import time
import urllib.request
import urllib.error
import warnings
from pathlib import Path

import pandas as pd

from .config import CACHE_DIR, CACHE_TTL_HOURS, SOURCES, LIVE_ADP_SOURCES, TEAM_FIXES

warnings.filterwarnings("ignore", category=FutureWarning)

_UA = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) ff-analytics/1.0"}

# Records which sources actually resolved, for the Methodology tab.
FETCH_LOG: list[dict] = []


def _cache_path(key: str) -> Path:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    return CACHE_DIR / f"{key}.parquet"


def _is_fresh(path: Path) -> bool:
    if not path.exists():
        return False
    age_hours = (time.time() - path.stat().st_mtime) / 3600
    return age_hours < CACHE_TTL_HOURS


def _download(url: str, timeout: int = 180) -> bytes:
    req = urllib.request.Request(url, headers=_UA)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def load(key: str, refresh: bool = False) -> pd.DataFrame:
    """Fetch a named source, using the local cache when fresh."""
    url = SOURCES[key]
    cpath = _cache_path(key)

    if not refresh and _is_fresh(cpath):
        df = pd.read_parquet(cpath)
        FETCH_LOG.append({"source": key, "url": url, "status": "cache",
                          "rows": len(df), "fetched": time.strftime(
                              "%Y-%m-%d %H:%M", time.localtime(cpath.stat().st_mtime))})
        return df

    raw = _download(url)
    if url.endswith(".parquet"):
        df = pd.read_parquet(io.BytesIO(raw))
    else:
        df = pd.read_csv(io.BytesIO(raw), low_memory=False)

    # Cache as parquet regardless of source format. Object columns holding
    # mixed types (common in the FantasyPros CSV) break the arrow writer,
    # so coerce those to string before persisting.
    try:
        df.to_parquet(cpath, index=False)
    except Exception:
        safe = df.copy()
        for col in safe.columns:
            if safe[col].dtype == object:
                safe[col] = safe[col].astype(str)
        safe.to_parquet(cpath, index=False)

    FETCH_LOG.append({"source": key, "url": url, "status": "live",
                      "rows": len(df),
                      "fetched": time.strftime("%Y-%m-%d %H:%M")})
    return df


def load_many(keys: list[str], refresh: bool = False) -> dict[str, pd.DataFrame]:
    out = {}
    for k in keys:
        try:
            out[k] = load(k, refresh=refresh)
            print(f"  [ok]   {k:<12} {len(out[k]):>7,} rows x {out[k].shape[1]:>3} cols")
        except Exception as exc:  # noqa: BLE001
            print(f"  [FAIL] {k:<12} {type(exc).__name__}: {str(exc)[:70]}")
            FETCH_LOG.append({"source": k, "url": SOURCES[k], "status": "failed",
                              "rows": 0, "fetched": time.strftime("%Y-%m-%d %H:%M")})
            out[k] = pd.DataFrame()
    return out


# --------------------------------------------------------------------------
# Live ADP. Best-effort: works on an open network, degrades to FantasyPros ECR
# in a restricted one. Whichever source wins is recorded per row downstream.
# --------------------------------------------------------------------------
def fetch_live_adp(timeout: int = 20) -> tuple[pd.DataFrame, str]:
    """Return (adp_frame, source_name). Empty frame if nothing is reachable."""
    for name, url in LIVE_ADP_SOURCES:
        try:
            raw = _download(url, timeout=timeout)
            payload = json.loads(raw)
        except Exception as exc:  # noqa: BLE001
            print(f"  [skip] live ADP '{name}' unreachable ({type(exc).__name__})")
            continue

        if name == "fantasyfootballcalculator":
            players = payload.get("players", [])
            if not players:
                continue
            df = pd.DataFrame(players)
            keep = {"name": "player", "position": "pos", "team": "team",
                    "adp": "adp", "stdev": "adp_stdev",
                    "high": "adp_best", "low": "adp_worst",
                    "times_drafted": "adp_times_drafted"}
            df = df[[c for c in keep if c in df.columns]].rename(columns=keep)
            df["team"] = df["team"].replace(TEAM_FIXES)
            print(f"  [ok]   live ADP from {name}: {len(df)} players")
            FETCH_LOG.append({"source": "live_adp", "url": url, "status": "live",
                              "rows": len(df), "fetched": time.strftime("%Y-%m-%d %H:%M")})
            return df, name

        if name == "sleeper":
            # Sleeper's player dump carries search_rank, a usable ADP proxy.
            rows = []
            for pid, p in payload.items():
                if not isinstance(p, dict):
                    continue
                rank = p.get("search_rank")
                if rank is None or rank > 2000:
                    continue
                rows.append({"player": p.get("full_name"), "pos": p.get("position"),
                             "team": p.get("team"), "adp": rank})
            if not rows:
                continue
            df = pd.DataFrame(rows).dropna(subset=["player"])
            df["team"] = df["team"].replace(TEAM_FIXES)
            print(f"  [ok]   live ADP from {name}: {len(df)} players")
            FETCH_LOG.append({"source": "live_adp", "url": url, "status": "live",
                              "rows": len(df), "fetched": time.strftime("%Y-%m-%d %H:%M")})
            return df, name

    print("  [note] no live ADP source reachable -> falling back to FantasyPros ECR")
    FETCH_LOG.append({"source": "live_adp", "url": "|".join(u for _, u in LIVE_ADP_SOURCES),
                      "status": "unreachable", "rows": 0,
                      "fetched": time.strftime("%Y-%m-%d %H:%M")})
    return pd.DataFrame(), "fantasypros_ecr"
