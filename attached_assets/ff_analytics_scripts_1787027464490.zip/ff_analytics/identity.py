"""The ID crosswalk.

nflverse keys on gsis_id, Pro-Football-Reference on pfr_id, Next Gen Stats on a
display name, FantasyPros on its own numeric id. Nothing joins cleanly. This
module builds one authoritative table mapping them all, and records how each
row was matched so the result is auditable rather than a black box.
"""
from __future__ import annotations

import re
import unicodedata

import pandas as pd

from .config import FUZZY_MATCH_THRESHOLD, TEAM_FIXES

_SUFFIXES = {"jr", "sr", "ii", "iii", "iv", "v"}


def norm_name(s) -> str:
    """Aggressively normalise a player name for matching.

    'Ja’Marr Chase' / "Ja'Marr Chase" / 'JaMarr Chase' -> 'jamarr chase'
    'Marvin Harrison Jr.' -> 'marvin harrison'
    """
    if s is None or (isinstance(s, float) and pd.isna(s)):
        return ""
    s = unicodedata.normalize("NFKD", str(s))
    s = s.encode("ascii", "ignore").decode("ascii")
    s = s.lower().replace(".", " ").replace("'", "").replace("`", "")
    s = re.sub(r"[^a-z\s-]", " ", s)
    s = s.replace("-", " ")
    parts = [p for p in s.split() if p]
    while len(parts) > 2 and parts[-1] in _SUFFIXES:
        parts.pop()
    return " ".join(parts)


def norm_team(s):
    """Fold alternate team codes to the nflverse standard.

    Returns None -- not "" -- for missing input, so downstream `.fillna()`
    cascades and `notna()` checks behave. An empty string would sail through
    a fillna chain and produce a team_2026 that matches no team-context row.
    """
    if s is None or (isinstance(s, float) and pd.isna(s)):
        return None
    t = str(s).upper().strip()
    if not t or t in {"NAN", "NONE", "FA", "<NA>"}:
        return None
    return TEAM_FIXES.get(t, t)


def build_crosswalk(players: pd.DataFrame, dp_ids: pd.DataFrame) -> pd.DataFrame:
    """One row per gsis_id with every foreign key we can attach."""
    p = players[[
        "gsis_id", "display_name", "pfr_id", "espn_id", "pff_id", "position",
        "position_group", "birth_date", "draft_year", "draft_round", "draft_pick",
        "rookie_season", "last_season", "years_of_experience", "latest_team",
        "status", "height", "weight", "college_name",
    ]].copy()
    p = p[p["gsis_id"].notna()].drop_duplicates(subset="gsis_id")
    p["merge_name"] = p["display_name"].map(norm_name)

    ids = dp_ids[["gsis_id", "fantasypros_id", "sleeper_id", "mfl_id",
                  "name", "position", "team"]].copy()
    ids = ids[ids["gsis_id"].notna()].drop_duplicates(subset="gsis_id")
    ids = ids.rename(columns={"position": "dp_position", "team": "dp_team",
                              "name": "dp_name"})

    xw = p.merge(ids[["gsis_id", "fantasypros_id", "sleeper_id", "mfl_id"]],
                 on="gsis_id", how="left")

    # Name-based backup index for FantasyPros rows dp_ids does not cover.
    dp_by_name = dp_ids[dp_ids["fantasypros_id"].notna()].copy()
    dp_by_name["merge_name"] = dp_by_name["name"].map(norm_name)
    dp_by_name["dp_position"] = dp_by_name["position"]
    dp_by_name = dp_by_name.drop_duplicates(subset=["merge_name", "dp_position"])

    xw.attrs["dp_by_name"] = dp_by_name[["merge_name", "dp_position",
                                         "fantasypros_id"]]
    return xw


def attach_fantasypros(target: pd.DataFrame, ecr: pd.DataFrame,
                       crosswalk: pd.DataFrame) -> pd.DataFrame:
    """Join FantasyPros ECR onto a gsis-keyed frame.

    Three passes, most-trustworthy first, with the method recorded per row:
      1. fantasypros_id from the dp_ids crosswalk   -> 'id'
      2. normalised name + position                 -> 'name_pos'
      3. fuzzy name within position                 -> 'fuzzy'
    """
    ecr = ecr.copy()
    ecr["merge_name"] = ecr["player"].map(norm_name)
    ecr["pos"] = ecr["pos"].astype(str).str.upper()
    ecr["fp_id_num"] = pd.to_numeric(ecr["id"], errors="coerce")

    ecr_cols = ["ecr", "sd", "best", "worst", "player_owned_avg", "bye",
                "rank_delta"]
    ecr_cols = [c for c in ecr_cols if c in ecr.columns]

    out = target.copy()
    out["merge_name"] = out["display_name"].map(norm_name)
    out["_pos"] = out["position"].astype(str).str.upper()
    for c in ecr_cols:
        out[c] = pd.NA
    out["match_quality"] = pd.NA

    # --- Pass 1: numeric FantasyPros id ---------------------------------
    by_id = ecr.dropna(subset=["fp_id_num"]).drop_duplicates("fp_id_num")
    by_id = by_id.set_index("fp_id_num")
    fp_num = pd.to_numeric(out.get("fantasypros_id"), errors="coerce")
    hit = fp_num.isin(by_id.index)
    for c in ecr_cols:
        out.loc[hit, c] = fp_num[hit].map(by_id[c]).values
    out.loc[hit, "match_quality"] = "id"

    # --- Pass 2: normalised name + position ------------------------------
    todo = out["match_quality"].isna()
    by_np = ecr.drop_duplicates(subset=["merge_name", "pos"]).set_index(
        ["merge_name", "pos"])
    keys = list(zip(out.loc[todo, "merge_name"], out.loc[todo, "_pos"]))
    found = pd.Series([k in by_np.index for k in keys], index=out.index[todo])
    idx = out.index[todo][found.values]
    if len(idx):
        sel_keys = [k for k, f in zip(keys, found.values) if f]
        for c in ecr_cols:
            out.loc[idx, c] = [by_np.loc[k, c] for k in sel_keys]
        out.loc[idx, "match_quality"] = "name_pos"

    # --- Pass 3: fuzzy within position -----------------------------------
    try:
        from rapidfuzz import process, fuzz
    except ImportError:
        process = None

    if process is not None:
        todo = out["match_quality"].isna()
        for pos in out.loc[todo, "_pos"].dropna().unique():
            pool = ecr[ecr["pos"] == pos]
            if pool.empty:
                continue
            choices = pool["merge_name"].tolist()
            rows = out.index[todo & (out["_pos"] == pos)]
            for i in rows:
                nm = out.at[i, "merge_name"]
                if not nm:
                    continue
                m = process.extractOne(nm, choices, scorer=fuzz.WRatio)
                if m and m[1] >= FUZZY_MATCH_THRESHOLD:
                    src = pool.iloc[m[2]]
                    for c in ecr_cols:
                        out.at[i, c] = src[c]
                    out.at[i, "match_quality"] = f"fuzzy:{int(m[1])}"

    out["match_quality"] = out["match_quality"].fillna("unmatched")
    return out.drop(columns=["_pos"])


def match_report(df: pd.DataFrame, label: str = "") -> dict:
    counts = df["match_quality"].value_counts().to_dict()
    matched = int((df["match_quality"] != "unmatched").sum())
    rate = matched / len(df) if len(df) else 0.0
    print(f"  [match] {label} {matched}/{len(df)} = {rate:.1%}  {counts}")
    return {"label": label, "matched": matched, "total": len(df),
            "rate": rate, "detail": counts}


def plausible_mask(cw: pd.DataFrame, stat_season: int,
                   market_season: int) -> pd.Series:
    """Players who could conceivably be on a current draft board.

    nflverse marks long-retired players as status ACT, and there are Mike
    Washingtons in both 1976 and 2026. Without this filter the upstream
    FantasyPros crosswalk happily hands you the 1976 one.
    """
    last = pd.to_numeric(cw.get("last_season"), errors="coerce")
    rookie = pd.to_numeric(cw.get("rookie_season"), errors="coerce")
    return (last >= stat_season - 1) | (rookie >= market_season)


def resolve_gsis(ecr: pd.DataFrame, crosswalk: pd.DataFrame,
                 dp_ids: pd.DataFrame, stat_season: int = 2025,
                 market_season: int = 2026) -> pd.DataFrame:
    """Attach a gsis_id to each FantasyPros row (the reverse of the join above).

    The FantasyPros ranking list is the universe driver, not the nflverse
    roster: the 2026 roster file lags on veterans who have signed but not been
    processed (Stefon Diggs, Deebo Samuel), and dropping them would put holes
    in the top 150. So we start from the ranking and hunt down the gsis_id.
    """
    e = ecr.copy()
    e["merge_name"] = e["player"].map(norm_name)
    e["pos"] = e["pos"].astype(str).str.upper()
    e["fp_id_num"] = pd.to_numeric(e["id"], errors="coerce")
    e["gsis_id"] = pd.NA
    e["id_match"] = pd.NA

    # Pass 1 -- FantasyPros id via the DynastyProcess crosswalk
    dp = dp_ids[dp_ids["fantasypros_id"].notna() & dp_ids["gsis_id"].notna()].copy()
    dp["fp_id_num"] = pd.to_numeric(dp["fantasypros_id"], errors="coerce")
    fp2gsis = dp.drop_duplicates("fp_id_num").set_index("fp_id_num")["gsis_id"]
    mapped = e["fp_id_num"].map(fp2gsis)
    hit = mapped.notna()
    e.loc[hit, "gsis_id"] = mapped[hit]
    e.loc[hit, "id_match"] = "fp_id"

    cw = crosswalk.copy()
    cw["_pos"] = cw["position"].astype(str).str.upper()
    cw["_plaus"] = plausible_mask(cw, stat_season, market_season)

    # --- Sanity-check pass 1 ------------------------------------------------
    # The DynastyProcess crosswalk is mostly excellent but not perfect: it maps
    # FantasyPros 28108 (Mike Washington Jr., a 2026 rookie RB) onto a
    # defensive back who last played in 1984. Reject any id-based match whose
    # position or era does not line up, and let the name passes re-resolve it.
    info = cw.set_index("gsis_id")
    grp = e["gsis_id"].map(info["_pos"])
    era_ok = e["gsis_id"].map(info["_plaus"]).fillna(False)
    pos_ok = (grp == e["pos"]) | grp.isna()
    # Position alone is too strict -- two-way players (Travis Hunter is a WR
    # on the draft board and a CB in the player file) would be thrown out. An
    # exact name match rescues those; the era check still catches the 1976 DB.
    name_ok = e["merge_name"] == e["gsis_id"].map(info["merge_name"])
    bad = e["gsis_id"].notna() & ~(era_ok & (pos_ok | name_ok))
    if bad.any():
        for _, row in e[bad].iterrows():
            print(f"  [id guard] rejected {row['player']} ({row['pos']}) -> "
                  f"{row['gsis_id']} ({info['_pos'].get(row['gsis_id'])}, "
                  f"last seen {info['last_season'].get(row['gsis_id'])})")
        e.loc[bad, "gsis_id"] = pd.NA
        e.loc[bad, "id_match"] = pd.NA

    # Pass 2 -- normalised name + position, among plausible players only
    cw = cw[cw["_plaus"]].copy()
    # Prefer currently-active players when a name collides across eras.
    cw["_active"] = (cw["status"].astype(str) == "ACT").astype(int)
    cw = cw.sort_values(["_active", "rookie_season"], ascending=[False, False])
    by_np = cw.drop_duplicates(subset=["merge_name", "_pos"]).set_index(
        ["merge_name", "_pos"])["gsis_id"]

    todo = e["gsis_id"].isna()
    keys = list(zip(e.loc[todo, "merge_name"], e.loc[todo, "pos"]))
    vals = [by_np.get(k, pd.NA) for k in keys]
    e.loc[todo, "gsis_id"] = vals
    e.loc[todo & e["gsis_id"].notna(), "id_match"] = "name_pos"

    # Pass 3 -- fuzzy within position
    try:
        from rapidfuzz import process, fuzz
    except ImportError:
        process = None

    if process is not None:
        todo = e["gsis_id"].isna()
        for pos in e.loc[todo, "pos"].dropna().unique():
            pool = cw[cw["_pos"] == pos]
            if pool.empty:
                continue
            choices = pool["merge_name"].tolist()
            for i in e.index[todo & (e["pos"] == pos)]:
                nm = e.at[i, "merge_name"]
                if not nm:
                    continue
                m = process.extractOne(nm, choices, scorer=fuzz.WRatio)
                if m and m[1] >= FUZZY_MATCH_THRESHOLD:
                    e.at[i, "gsis_id"] = pool.iloc[m[2]]["gsis_id"]
                    e.at[i, "id_match"] = f"fuzzy:{int(m[1])}"

    e["id_match"] = e["id_match"].fillna("unresolved")
    return e
