"""Assemble the top-250 analytics table and write the workbook.

    python -m ff_analytics.build --out top250_2026.xlsx
"""
from __future__ import annotations

import argparse
import warnings

import numpy as np
import pandas as pd

from . import identity as idm
from . import market, player_metrics as pm, sources, team_context as tc, universe as uni
from .config import (MIN_GAMES_FOR_RATES, MIN_TARGETS_FOR_RATES,
                     MIN_CARRIES_FOR_RATES, STAT_SEASON, MARKET_SEASON, TOP_N)

warnings.filterwarnings("ignore")

SRC_KEYS = ["players", "dp_ids", "fp_ecr", "roster_mkt", "depth_mkt", "weekly",
            "snaps", "ngs_rec", "ngs_rush", "adv_rush", "adv_pass", "adv_rec",
            "pbp", "games", "dp_values"]


def _safe_div(a, b):
    a = pd.to_numeric(a, errors="coerce")
    b = pd.to_numeric(b, errors="coerce")
    return (a / b.replace(0, np.nan)).round(3)


def assemble(refresh: bool = False, top_n: int = TOP_N) -> dict:
    print("\n[1/6] Fetching sources")
    S = sources.load_many(SRC_KEYS, refresh=refresh)

    print("\n[2/6] Resolving identities and the draft board")
    xw = idm.build_crosswalk(S["players"], S["dp_ids"])
    u = uni.build(S["fp_ecr"], xw, S["dp_ids"], S["roster_mkt"],
                  S["depth_mkt"], S["players"], top_n=top_n)
    print(f"  universe: {len(u)} players | id match: "
          f"{u['id_match'].value_counts().to_dict()}")
    print(f"  2026 team source: {u['team_source'].value_counts().to_dict()}")

    print("\n[3/6] Team context (O-line + offensive environment)")
    team = tc.build(S["pbp"], S["players"], S["adv_pass"], S["adv_rush"],
                    S["snaps"], S["depth_mkt"], S["roster_mkt"], STAT_SEASON)
    print(f"  {len(team)} teams graded")

    print("\n[4/6] Player metrics")
    activity = pm.weekly_activity(S["weekly"], S["snaps"], S["players"])
    tot = pm.season_totals(S["weekly"])
    shares = pm.opportunity_shares(S["weekly"], activity)
    cons = pm.consistency(S["weekly"], activity)
    rz = pm.red_zone(S["pbp"])
    snaps = pm.snap_share(S["snaps"], S["players"])
    ngs = pm.ngs_season(S["ngs_rec"], S["ngs_rush"], STAT_SEASON)
    pfr = pm.pfr_advanced(S["adv_rush"], S["adv_rec"], S["players"], STAT_SEASON)

    # Resolve 2026 teams for EVERY 2025 producer, not just the draft board --
    # otherwise every unranked contributor looks like departed volume.
    all_producers = pd.Series(S["weekly"]["player_id"].dropna().unique())
    team_all = uni.resolve_team_2026(all_producers, S["roster_mkt"],
                                     S["depth_mkt"], S["players"])
    team26 = team_all.drop_duplicates("gsis_id").set_index("gsis_id")["team_2026"]
    print(f"  2026 teams resolved for {team26.notna().sum():,}/"
          f"{len(team26):,} of the 2025 player pool")
    vac = pm.vacated_opportunity(S["weekly"], team26, S["pbp"])
    print(f"  totals={len(tot)} shares={len(shares)} rz={len(rz)} "
          f"ngs={len(ngs)} pfr={len(pfr)}")

    print("\n[5/6] Merging")
    df = u.copy()
    for frame in (tot, shares, cons, rz, ngs, pfr):
        f = frame.drop_duplicates("gsis_id")
        df = df.merge(f, on="gsis_id", how="left", suffixes=("", "_dup"))
    df = df.merge(snaps.drop_duplicates("gsis_id")[
        ["gsis_id", "offense_snaps", "snap_pct_avg", "snap_games"]],
        on="gsis_id", how="left")

    # Biographical detail from the nflverse player table.
    bio = S["players"][["gsis_id", "birth_date", "draft_year", "draft_round",
                        "draft_pick", "rookie_season", "last_season",
                        "years_of_experience", "height", "weight",
                        "college_name"]].drop_duplicates("gsis_id")
    df = df.merge(bio, on="gsis_id", how="left")
    df["age"] = ((pd.Timestamp.today() - pd.to_datetime(df["birth_date"],
                                                        errors="coerce"))
                 .dt.days / 365.25).round(1)
    # draft_year is blank for 2026 arrivals in the current player file, so
    # rookie_season is the reliable flag.
    df["is_rookie"] = ((pd.to_numeric(df["rookie_season"], errors="coerce")
                        >= MARKET_SEASON)
                       | (pd.to_numeric(df["draft_year"], errors="coerce")
                          >= MARKET_SEASON)).fillna(False)

    # Team context joins on the 2026 team -- the situation he is walking into,
    # not the one he left.
    tcols = {c: f"tm_{c}" for c in team.columns if c != "team"}
    # The ECR frame already carries a `team`, so merge on a private key rather
    # than letting pandas emit team_x / team_y into the Raw tab.
    df = df.merge(team.rename(columns=tcols).rename(columns={"team": "_tm_key"}),
                  left_on="team_2026", right_on="_tm_key", how="left") \
           .drop(columns=["_tm_key"], errors="ignore")
    vcols = {c: f"tm_{c}" for c in vac.columns if c != "team"}
    df = df.merge(vac.rename(columns=vcols).rename(columns={"team": "_vac_key"}),
                  left_on="team_2026", right_on="_vac_key", how="left") \
           .drop(columns=["_vac_key"], errors="ignore")

    print("\n[6/6] Deriving")
    df = derive(df)

    live_adp, adp_src = sources.fetch_live_adp()
    df = market.attach_adp(df, live_adp, adp_src)
    df = market.value_scores(df)
    return {"master": df, "team": team, "vacated": vac, "universe": u}


def derive(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()

    # season_totals and players.parquet both carry a 'position'; the draft
    # board's own 'pos' is the one we rank on, so it becomes canonical.
    d = d.drop(columns=["position", "position_dup", "name_2025", "team",
                        "team_x", "team_y"], errors="ignore")

    # --- rename the production block with an explicit season prefix, so a
    # --- 2025 stat can never be mistaken for a 2026 projection --------------
    ren = {
        "fantasy_points_ppr": "y25_ppr_total",
        "fantasy_points": "y25_standard_total",
        "fantasy_points_half_ppr": "y25_half_ppr_total",
        "games": "y25_games", "games_active": "y25_games_active",
        "targets": "y25_targets", "receptions": "y25_receptions",
        "receiving_yards": "y25_rec_yards", "receiving_tds": "y25_rec_tds",
        "receiving_air_yards": "y25_air_yards",
        "receiving_yards_after_catch": "y25_yac",
        "carries": "y25_carries", "rushing_yards": "y25_rush_yards",
        "rushing_tds": "y25_rush_tds", "attempts": "y25_pass_attempts",
        "passing_yards": "y25_pass_yards", "passing_tds": "y25_pass_tds",
        "passing_interceptions": "y25_interceptions",
        "target_share": "y25_target_share",
        "target_share_active": "y25_target_share_active",
        "carry_share": "y25_carry_share",
        "carry_share_active": "y25_carry_share_active",
        "air_yards_share": "y25_air_yards_share",
        "air_yards_share_active": "y25_air_yards_share_active",
        "wopr": "y25_wopr", "team_2025": "y25_team",
        "offense_snaps": "y25_snaps", "snap_pct_avg": "y25_snap_pct",
        "rz_opportunities": "y25_rz_opportunities",
        "inside_10_touches": "y25_inside_10_touches",
        "inside_5_touches": "y25_inside_5_touches",
        "total_tds": "y25_total_tds", "expected_tds": "y25_expected_tds",
        "td_over_expected": "y25_td_over_expected",
        "weekly_floor": "y25_weekly_floor",
        "weekly_ceiling": "y25_weekly_ceiling",
        "weekly_median": "y25_weekly_median",
        "weekly_stdev": "y25_weekly_stdev",
        "boom_rate": "y25_boom_rate", "bust_rate": "y25_bust_rate",
        "coef_variation": "y25_coef_variation",
        "weeks_played": "y25_weeks_played",
        "player": "player", "pos": "position",
    }
    d = d.rename(columns={k: v for k, v in ren.items() if k in d.columns})

    g = pd.to_numeric(d.get("y25_games"), errors="coerce")
    d["y25_ppr_ppg"] = _safe_div(d["y25_ppr_total"], g)
    d["y25_half_ppr_ppg"] = _safe_div(d["y25_half_ppr_total"], g)
    d["y25_standard_ppg"] = _safe_div(d["y25_standard_total"], g)
    d["y25_targets_per_game"] = _safe_div(d["y25_targets"], g)
    d["y25_carries_per_game"] = _safe_div(d["y25_carries"], g)

    d["y25_opportunities"] = (pd.to_numeric(d["y25_targets"], errors="coerce").fillna(0)
                              + pd.to_numeric(d["y25_carries"], errors="coerce").fillna(0))
    d["y25_points_per_opportunity"] = _safe_div(d["y25_ppr_total"],
                                                d["y25_opportunities"])
    d["y25_points_per_snap"] = _safe_div(d["y25_ppr_total"], d["y25_snaps"])
    d["y25_yards_per_target"] = _safe_div(d["y25_rec_yards"], d["y25_targets"])
    d["y25_yards_per_reception"] = _safe_div(d["y25_rec_yards"], d["y25_receptions"])
    d["y25_catch_rate"] = _safe_div(d["y25_receptions"], d["y25_targets"])
    d["y25_yards_per_carry"] = _safe_div(d["y25_rush_yards"], d["y25_carries"])
    d["y25_adot"] = _safe_div(d["y25_air_yards"], d["y25_targets"])
    d["y25_yac_per_rec"] = _safe_div(d["y25_yac"], d["y25_receptions"])
    d["y25_racr"] = _safe_div(d["y25_rec_yards"], d["y25_air_yards"])
    d["y25_td_rate_per_opp"] = _safe_div(d["y25_total_tds"], d["y25_opportunities"])
    d["y25_rush_epa_per_att"] = _safe_div(d.get("rushing_epa"), d["y25_carries"])
    d["y25_rec_epa_per_target"] = _safe_div(d.get("receiving_epa"), d["y25_targets"])

    # Rates computed off a handful of games are noise. Blank them rather than
    # printing a number the sheet will be trusted on.
    thin = g.fillna(0) < MIN_GAMES_FOR_RATES
    for c in ("y25_points_per_opportunity", "y25_td_rate_per_opp",
              "y25_coef_variation", "y25_points_per_snap"):
        if c in d.columns:
            d.loc[thin, c] = np.nan

    # Rate stats also need a denominator worth dividing by. A running back
    # with two targets and one drop is not a 50%-drop-rate receiver, and the
    # colour scale will happily rank him last in the league for it.
    few_tgt = (thin | (pd.to_numeric(d["y25_targets"], errors="coerce").fillna(0)
                       < MIN_TARGETS_FOR_RATES))
    for c in ("y25_yards_per_target", "y25_racr", "y25_adot", "y25_catch_rate",
              "y25_yac_per_rec", "y25_yards_per_reception", "rec_drop_pct",
              "rec_ybc_per_rec", "rec_yac_per_rec", "rec_adot"):
        if c in d.columns:
            d.loc[few_tgt, c] = np.nan

    few_car = (thin | (pd.to_numeric(d["y25_carries"], errors="coerce").fillna(0)
                       < MIN_CARRIES_FOR_RATES))
    for c in ("y25_yards_per_carry", "rush_ybc_per_att", "rush_yac_per_att",
              "rush_att_per_broken", "y25_rush_epa_per_att"):
        if c in d.columns:
            d.loc[few_car, c] = np.nan

    # A rookie has no 2025 NFL production. That is a blank, not a zero -- the
    # difference matters when you sort the sheet.
    prod_cols = [c for c in d.columns if c.startswith("y25_")]
    rookie = d["is_rookie"].fillna(False) & (g.fillna(0) == 0)
    for c in prod_cols:
        d.loc[rookie, c] = np.nan

    d["notes"] = np.where(rookie, "Rookie - no 2025 NFL production", "")
    # A veteran with no 2025 line missed the whole season (injury, suspension,
    # free agency). Say so, rather than leaving an unexplained blank row.
    vet_blank = (~rookie) & d["y25_ppr_total"].isna()
    d.loc[vet_blank, "notes"] = "No 2025 regular-season production - missed season"
    d.loc[d["team_source"] == "players_latest_team", "notes"] = (
        d.loc[d["team_source"] == "players_latest_team", "notes"]
        + " | 2026 team inferred, not on official roster file")
    return d


def main():
    ap = argparse.ArgumentParser(
        description="Build the top-250 NFL fantasy analytics workbook.")
    ap.add_argument("--out", default="top250_2026_fantasy_analytics.xlsx",
                    help="output .xlsx path")
    ap.add_argument("--n", type=int, default=TOP_N, help="how many players")
    ap.add_argument("--refresh", action="store_true",
                    help="ignore the local cache and re-download every source")
    ap.add_argument("--csv", action="store_true",
                    help="also write the master table as CSV")
    args = ap.parse_args()

    result = assemble(refresh=args.refresh, top_n=args.n)
    adp_source = result["master"]["adp_source"].mode()
    adp_source = adp_source.iloc[0] if len(adp_source) else "unknown"

    from .workbook import write
    path = write(result, args.out, sources.FETCH_LOG, adp_source)
    print(f"\nWorkbook written: {path}")

    if args.csv:
        csv_path = args.out.rsplit(".", 1)[0] + "_master.csv"
        result["master"].to_csv(csv_path, index=False)
        print(f"CSV written: {csv_path}")
    return result


if __name__ == "__main__":
    main()
