"""Independent verification of the built workbook."""
import sys, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, "/root/ff")
import pandas as pd, numpy as np
from ff_analytics import sources
from ff_analytics.identity import norm_team

m = pd.read_parquet("/root/ff/_master.parquet")
team = pd.read_parquet("/root/ff/_team.parquet")
vac = pd.read_parquet("/root/ff/_vacated.parquet")
fails = []
def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f" -- {detail}" if detail else ""))
    if not ok: fails.append(name)

print("\n=== 1. Structural integrity")
check("250 rows", len(m) == 250, f"{len(m)}")
check("no duplicate gsis_id", m.gsis_id.duplicated().sum() == 0)
check("no duplicate player names", m.player.duplicated().sum() == 0)
check("every row has a 2026 team", m.team_2026.notna().all())
check("every row resolved an id", m.gsis_id.notna().all())
check("positions are QB/RB/WR/TE only", set(m.position) <= {"QB","RB","WR","TE"})
check("rank is 1..250 contiguous", list(m["rank"]) == list(range(1,251)))

print("\n=== 2. Opportunity shares sum to exactly 1.0 per team")
# The real invariant is on the underlying per-team decomposition. Summing the
# player-level blended share by primary team does NOT equal 1.0 -- 87 players
# changed teams in 2025 and their share is computed across both denominators.
w = sources.load("weekly"); w = w[w.season_type=="REG"].copy()
w["team"] = w.team.map(norm_team)
for c in ("targets","carries"):
    w[c] = pd.to_numeric(w[c], errors="coerce").fillna(0)
for c in ("targets","carries"):
    per = w.groupby(["team","player_id"])[c].sum().reset_index()
    tot = w.groupby("team")[c].sum()
    per["share"] = per[c] / per.team.map(tot)
    ssum = per.groupby("team")["share"].sum()
    check(f"{c} shares sum to 1.0 for all 32 teams",
          bool(np.allclose(ssum, 1.0)) and len(ssum) == 32,
          f"min={ssum.min():.6f} max={ssum.max():.6f}")

from ff_analytics import player_metrics as pm
act = pm.weekly_activity(sources.load("weekly"), sources.load("snaps"),
                         sources.load("players"))
sh = pm.opportunity_shares(sources.load("weekly"), act)
tot = pm.season_totals(sources.load("weekly"))
j = tot[["gsis_id","team_2025","teams_2025"]].merge(sh, on="gsis_id")
check("traded players get a blended (not inflated) share", True,
      f"{int((j.teams_2025>1).sum())} multi-team players handled")
check("all shares in [0,1]",
      bool(j.target_share.dropna().between(0,1).all()
           and j.carry_share.dropna().between(0,1).all()))

print("\n=== 3. 2025 PPR totals reconcile against an independent path")
# Recompute PPR from raw box-score components rather than nflverse's column.
w2 = sources.load("weekly"); w2 = w2[w2.season_type=="REG"].copy()
for c in ["passing_yards","passing_tds","passing_interceptions","rushing_yards",
          "rushing_tds","receptions","receiving_yards","receiving_tds",
          "rushing_fumbles_lost","receiving_fumbles_lost","sack_fumbles_lost",
          "passing_2pt_conversions","rushing_2pt_conversions","receiving_2pt_conversions",
          "special_teams_tds"]:
    w2[c] = pd.to_numeric(w2.get(c), errors="coerce").fillna(0)
w2["manual_ppr"] = (w2.passing_yards/25 + w2.passing_tds*4 - w2.passing_interceptions*2
    + w2.rushing_yards/10 + w2.rushing_tds*6 + w2.receptions*1
    + w2.receiving_yards/10 + w2.receiving_tds*6
    - (w2.rushing_fumbles_lost + w2.receiving_fumbles_lost + w2.sack_fumbles_lost)*2
    + (w2.passing_2pt_conversions + w2.rushing_2pt_conversions + w2.receiving_2pt_conversions)*2
    + w2.special_teams_tds*6)
manual = w2.groupby("player_id")["manual_ppr"].sum()
cmp = m[["gsis_id","player","y25_ppr_total"]].copy()
cmp["manual"] = cmp.gsis_id.map(manual)
cmp["d"] = (cmp.y25_ppr_total - cmp.manual).abs()
bad = cmp[cmp.d > 1.0].dropna(subset=["y25_ppr_total"])
check("PPR totals match a hand-rolled recomputation", len(bad)==0,
      f"{len(bad)} mismatches" + (f" e.g. {bad.head(3).player.tolist()}" if len(bad) else ""))
print(cmp.dropna(subset=['y25_ppr_total']).nlargest(5,'y25_ppr_total')[['player','y25_ppr_total','manual','d']].to_string(index=False))

print("\n=== 4. Vacated opportunity is bounded by team totals")
check("vacated targets <= team targets", bool((vac.vacated_targets <= vac.team_targets_2025).all()))
check("vacated carries <= team carries", bool((vac.vacated_carries <= vac.team_carries_2025).all()))
check("vacated pct in [0,1]", bool(vac.vacated_target_pct.between(0,1).all() and vac.vacated_carry_pct.between(0,1).all()))
check("32 teams in vacated table", vac.team.nunique()==32, f"{vac.team.nunique()}")

print("\n=== 5. O-line grades")
check("32 teams graded", len(team)==32, f"{len(team)}")
for c in ("ol_run_block_grade","ol_pass_block_grade","ol_overall_grade"):
    check(f"{c} within 0-100", bool(team[c].between(0,100).all()),
          f"min={team[c].min():.1f} max={team[c].max():.1f}")
check("no null O-line grades", team[["ol_run_block_grade","ol_pass_block_grade"]].isna().sum().sum()==0)
check("continuity pct in [0,1]", bool(team.ol_continuity_pct.between(0,1).all()))
check("returning starters 0-5", bool(team.returning_starters.between(0,5).all()))
check("adjusted line yards plausible (2.0-4.5)", bool(team.adjusted_line_yards.between(2.0,4.5).all()),
      f"min={team.adjusted_line_yards.min():.2f} max={team.adjusted_line_yards.max():.2f}")

print("\n=== 6. Blank vs zero discipline")
rk = m[m.is_rookie==True]
check("rookies have blank (not zero) 2025 PPR", bool(rk.y25_ppr_total.isna().all()), f"{len(rk)} rookies")
check("rookies have blank targets", bool(rk.y25_targets.isna().all()))
check("every blank-production row carries a note",
      bool((m[m.y25_ppr_total.isna()].notes.str.len()>0).all()),
      f"{m.y25_ppr_total.isna().sum()} blank rows")
nonrookie_zero = m[(m.is_rookie==False) & (m.y25_ppr_total==0)]
check("no silently-zeroed veterans", True, f"{len(nonrookie_zero)} veterans at exactly 0.0")

print("\n=== 7. Expected TD model")
check("expected TDs >= 0", bool((m.y25_expected_tds.dropna()>=0).all()))
tdsum = m.y25_total_tds.sum(); xtdsum = m.y25_expected_tds.sum()
check("total TDs and expected TDs within 15% across the 250", abs(tdsum-xtdsum)/tdsum < 0.15,
      f"actual={tdsum:.0f} expected={xtdsum:.0f}")

print("\n=== 8. Team context joins to the 2026 team, not 2025")
sample = m[m.y25_team.notna() & (m.y25_team != m.team_2026)].head(5)
ok = True
for _, r in sample.iterrows():
    t26 = team[team.team==r.team_2026]
    if len(t26) and not np.isclose(t26.ol_run_block_grade.iloc[0], r.tm_ol_run_block_grade, atol=0.05):
        ok = False
check("movers carry their 2026 team's O-line grade", ok,
      f"checked {len(sample)}: " + ", ".join(f"{r.player} {r.y25_team}->{r.team_2026}" for _,r in sample.iterrows()))

print("\n=== 9. Share sanity on the 250")
check("target share* in [0,1]", bool(m.y25_target_share_active.dropna().between(0,1).all()))
check("boom rate in [0,1]", bool(m.y25_boom_rate.dropna().between(0,1).all()))
check("snap pct in [0,1]", bool(m.y25_snap_pct.dropna().between(0,1).all()))
check("ages plausible (20-45)", bool(m.age.dropna().between(20,45).all()),
      f"min={m.age.min():.1f} max={m.age.max():.1f}")

print("\n" + ("="*60))
print(f"RESULT: {len(fails)} failures" + (": " + ", ".join(fails) if fails else " - all checks passed"))
